# LedgerLens.ai — AI-Powered Equity Intelligence Platform

LedgerLens.ai helps financial analysts monitor NSE-listed companies by tracking
watchlists, ingesting annual reports/filings via an **NSE MCP Server**, indexing them
into a **RAG knowledge base** (Pinecone + Gemini embeddings), and providing an
AI chatbot (LangGraph + Gemini) for analysis, comparisons, and analyst-sentiment summaries.

---

## 📁 Project Structure

```
ledgerlens/
├── backend/
│   ├── app.py                 # Flask application factory
│   ├── config.py              # Environment-based configuration
│   ├── extensions.py          # Flask extensions (db, jwt, scheduler, etc.)
│   ├── requirements.txt
│   ├── auth/                  # JWT login & profile
│   ├── users/                 # User profile management
│   ├── companies/             # Company search & detail
│   ├── watchlist/             # Watchlist CRUD
│   ├── documents/             # Document download & listing
│   ├── rag/                   # RAG processing pipeline + LangGraph workflow
│   ├── chat/                  # Chat & Compare endpoints
│   ├── sentiment/             # Sentiment analysis on analyst reports
│   ├── scheduler/              # Scheduler status/trigger endpoints
│   ├── dashboard/              # Dashboard aggregation
│   ├── mcp/                    # NSE MCP integration endpoints
│   ├── analyst_reports/        # Manual analyst report upload
│   ├── services/
│   │   ├── mcp_service.py       # NSE MCP client wrapper
│   │   ├── s3_service.py        # AWS S3 storage
│   │   ├── pinecone_service.py  # Pinecone vector DB
│   │   ├── gemini_service.py    # Gemini LLM
│   │   ├── embedding_service.py # Gemini embeddings
│   │   ├── chunking_service.py  # Text chunking
│   │   ├── extraction_service.py# PDF text extraction
│   │   └── scheduler_service.py # APScheduler watchlist refresh logic
│   ├── models/                  # SQLAlchemy ORM models
│   ├── migrations/              # Alembic migrations
│   └── scripts/seed_data.py     # Demo data seeder
│
├── frontend/
│   ├── login.html
│   ├── dashboard.html
│   ├── company.html
│   ├── companies.html
│   ├── watchlist.html
│   ├── documents.html
│   ├── compare.html
│   ├── chat.html
│   ├── analyst_reports.html
│   ├── css/main.css
│   ├── js/{core.js, layout.js}
│   └── static/swagger.json
│
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md
```

---

## 🧩 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, Vanilla JS, Bootstrap-inspired custom design system |
| Backend | Python Flask, Flask Blueprints, Flask-JWT-Extended, SQLAlchemy |
| Database | PostgreSQL |
| Storage | AWS S3 (presigned URLs) |
| Vector DB | Pinecone |
| LLM | Google Gemini |
| Embeddings | Gemini Embeddings (`models/embedding-001`) |
| Agent Framework | LangGraph + LangChain |
| Document Source | NSE MCP Server (`nse_corporate_announcements`) — **no web scraping** |
| Scheduler | APScheduler |
| Containerization | Docker / docker-compose |

---

## 🚀 Quick Start (Docker)

### 1. Clone & configure environment

```bash
cp .env.example .env
# Edit .env and fill in: AWS keys, Pinecone key, Gemini API key, NSE_MCP_URL
```

### 2. Start the NSE MCP Server (separate process)

This platform expects an NSE MCP server running locally at `http://localhost:3000/mcp`
that exposes the `nse_corporate_announcements` tool. Start it per its own
documentation before running the scheduler/refresh features. If unavailable,
the `mcp_service.py` falls back to a mock response so the rest of the app
remains functional for development.

### 3. Build and run with Docker Compose

```bash
docker-compose up --build
```

This starts:
- **PostgreSQL** on `localhost:5432`
- **Redis** on `localhost:6379`
- **Flask backend** on `localhost:5000` (serves the frontend too)

### 4. Run migrations & seed demo data

```bash
docker-compose exec backend flask db upgrade
docker-compose exec backend python scripts/seed_data.py
```

### 5. Open the app

Visit **http://localhost:5000** — you'll be redirected to the login page.

**Demo credentials:**
```
Email:    analyst@ledgerlens.ai
Password: LedgerLens@2024
```

---

## 🛠 Local Development (without Docker)

```bash
cd backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Set up PostgreSQL locally and update DATABASE_URL in .env
export FLASK_APP=app.py
flask db upgrade
python scripts/seed_data.py

flask run --host=0.0.0.0 --port=5000
```

---

## 📡 API Overview

All endpoints are prefixed with `/api/v1`. Full interactive documentation is
available via Swagger UI at:

```
http://localhost:5000/api/docs
```

### Key Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/auth/login` | JWT login |
| GET | `/auth/profile` | Current user profile |
| GET | `/dashboard` | Dashboard stats & recent updates |
| GET | `/companies/search?q=` | Search NSE companies |
| GET | `/companies/<symbol>` | Company detail + stats |
| GET/POST | `/watchlist` | List / add watchlist entries |
| DELETE/PATCH | `/watchlist/<symbol>` | Remove / update frequency |
| GET | `/companies/<symbol>/documents` | Annual reports & filings |
| GET | `/documents/<id>/download` | S3 presigned download URL |
| GET | `/mcp/<symbol>/announcements` | Fetch via NSE MCP |
| POST | `/mcp/<symbol>/refresh` | Manual refresh from NSE |
| POST | `/rag/process/<document_id>` | Run RAG ingestion pipeline |
| GET | `/rag/status/<document_id>` | RAG processing status |
| POST | `/chat` | AI chatbot (LangGraph) |
| POST | `/compare` | Multi-company comparison |
| GET/POST | `/analyst-reports` | List / upload analyst reports |
| POST | `/analyst-reports/<id>/analyze` | Run Gemini sentiment analysis |
| GET | `/companies/<symbol>/sentiment` | Sentiment summary |
| POST | `/scheduler/run` | Manually trigger watchlist refresh |
| GET | `/scheduler/status` | Scheduler & job status |

---

## 🔄 Document Ingestion Pipeline

```
NSE MCP Server (nse_corporate_announcements)
        ↓
   New Announcement Detected
        ↓
   Download PDF → Upload to S3 → Create Document Record
        ↓
   Extract Text (PyMuPDF) → Chunk Text → Gemini Embeddings → Pinecone
```

Triggered by:
- **APScheduler** (every 6 hours, respects per-watchlist frequency: daily/weekly/monthly/manual)
- **Manual refresh** via `/api/v1/mcp/<symbol>/refresh`
- **Manual RAG processing** via `/api/v1/rag/process/<document_id>`

---

## 🤖 Chatbot (LangGraph Workflow)

`backend/rag/workflow.py` implements a LangGraph state machine:

```
classify_query → retrieve_context (Pinecone) → generate_answer (Gemini) → END
                         ↓ (on error)
                    handle_error → END
```

Query types: `summary`, `analysis`, `risk`, `growth`, `comparison` — each routed
to a tailored system prompt.

---

## 📊 Analyst Reports & Sentiment (Manual Upload Only)

Per spec, **no automated ingestion** for analyst reports. Analysts upload PDFs
via the "Analyst Reports" page (`/analyst_reports.html`), which:

1. Stores the PDF in S3 (`analyst_reports/<symbol>/<broker>/...`)
2. Stores metadata (broker, date, rating, target price) in PostgreSQL
3. Optionally runs Gemini sentiment analysis → stores Buy/Hold/Sell counts +
   sentiment score in `sentiment_scores`

---

## 🗄 Database Schema

| Table | Purpose |
|---|---|
| `users` | Platform users (JWT auth) |
| `companies` | NSE company master data |
| `watchlists` | User ↔ Company with update frequency |
| `documents` | Annual reports & filings (S3 + processing status) |
| `chunks` | Text chunks + Pinecone vector IDs |
| `analyst_reports` | Manually uploaded broker reports |
| `sentiment_scores` | Aggregated Buy/Hold/Sell sentiment |
| `update_logs` | Scheduler/MCP/RAG audit trail |

Migrations are managed with **Flask-Migrate / Alembic** in `backend/migrations/`.

---

## 🔐 Environment Variables

See `.env.example` for the full list. Required for full functionality:

- `DATABASE_URL` — PostgreSQL connection string
- `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `S3_BUCKET_NAME`
- `PINECONE_API_KEY`, `PINECONE_INDEX_NAME`
- `GEMINI_API_KEY`
- `NSE_MCP_URL` (default: `http://localhost:3000/mcp`)
- `JWT_SECRET_KEY`, `SECRET_KEY`

---

## 📝 Notes

- The NSE MCP Server is the **only** automated document source — no web scraping
  is performed anywhere in the codebase.
- `mcp_service.py` includes a mock-response fallback so the app remains usable
  in development environments without a running MCP server.
- Pinecone index is auto-created (dimension 768, cosine metric) on first use if
  it doesn't already exist.
- The demo dataset includes 4 companies (TCS, INFY, WIPRO, HDFCBANK) for the
  analyst-reports/sentiment demo flow — add more via the Watchlist page.
