"""
LedgerLens.ai — Flask Extensions
All extensions are instantiated here and bound to the app in app.py.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_migrate import Migrate
from flask_cors import CORS
from flask_marshmallow import Marshmallow
from apscheduler.schedulers.background import BackgroundScheduler
import structlog

# Core extensions
db = SQLAlchemy()
jwt = JWTManager()
migrate = Migrate()
cors = CORS()
ma = Marshmallow()

# Scheduler (singleton)
scheduler = BackgroundScheduler(timezone="Asia/Kolkata")

# Structured logger
logger = structlog.get_logger(__name__)
