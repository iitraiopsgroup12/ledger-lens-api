"""
LedgerLens.ai — SQLAlchemy ORM Models
All database table definitions for the platform.
"""

from datetime import datetime
import uuid
from extensions import db
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy import Index


def generate_uuid():
    return str(uuid.uuid4())


# ============================================================
# User Model
# ============================================================

class User(db.Model):
    """Platform user with authentication credentials."""
    __tablename__ = "users"

    id = db.Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(255), nullable=True)
    role = db.Column(db.String(50), default="analyst")
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)

    # Relationships
    watchlists = db.relationship("Watchlist", backref="user", lazy="dynamic", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<User {self.email}>"

    def to_dict(self):
        return {
            "id": self.id,
            "email": self.email,
            "full_name": self.full_name,
            "role": self.role,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_login": self.last_login.isoformat() if self.last_login else None,
        }


# ============================================================
# Company Model
# ============================================================

class Company(db.Model):
    """NSE-listed company master data."""
    __tablename__ = "companies"

    id = db.Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    symbol = db.Column(db.String(20), unique=True, nullable=False, index=True)
    name = db.Column(db.String(255), nullable=False)
    isin = db.Column(db.String(20), nullable=True)
    sector = db.Column(db.String(100), nullable=True)
    industry = db.Column(db.String(100), nullable=True)
    market_cap = db.Column(db.Numeric(20, 2), nullable=True)
    description = db.Column(db.Text, nullable=True)
    website = db.Column(db.String(255), nullable=True)
    nse_series = db.Column(db.String(10), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    last_updated = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    meta_data = db.Column(JSONB, nullable=True)

    # Relationships
    documents = db.relationship("Document", backref="company", lazy="dynamic", cascade="all, delete-orphan")
    analyst_reports = db.relationship("AnalystReport", backref="company", lazy="dynamic", cascade="all, delete-orphan")
    watchlists = db.relationship("Watchlist", backref="company", lazy="dynamic", cascade="all, delete-orphan")
    sentiment_scores = db.relationship("SentimentScore", backref="company", lazy="dynamic", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Company {self.symbol}>"

    def to_dict(self):
        return {
            "id": self.id,
            "symbol": self.symbol,
            "name": self.name,
            "isin": self.isin,
            "sector": self.sector,
            "industry": self.industry,
            "market_cap": float(self.market_cap) if self.market_cap else None,
            "description": self.description,
            "website": self.website,
            "is_active": self.is_active,
            "last_updated": self.last_updated.isoformat() if self.last_updated else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# ============================================================
# Watchlist Model
# ============================================================

class Watchlist(db.Model):
    """User watchlist entry linking a user to a company with update frequency."""
    __tablename__ = "watchlists"

    id = db.Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    user_id = db.Column(UUID(as_uuid=False), db.ForeignKey("users.id"), nullable=False)
    company_id = db.Column(UUID(as_uuid=False), db.ForeignKey("companies.id"), nullable=False)
    update_frequency = db.Column(db.String(20), default="weekly")  # daily, weekly, monthly, manual
    is_active = db.Column(db.Boolean, default=True)
    last_checked = db.Column(db.DateTime, nullable=True)
    next_check = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text, nullable=True)

    __table_args__ = (
        db.UniqueConstraint("user_id", "company_id", name="uq_user_company_watchlist"),
        Index("ix_watchlist_user_id", "user_id"),
        Index("ix_watchlist_company_id", "company_id"),
    )

    def __repr__(self):
        return f"<Watchlist user={self.user_id} company={self.company_id}>"

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "company_id": self.company_id,
            "company": self.company.to_dict() if self.company else None,
            "update_frequency": self.update_frequency,
            "is_active": self.is_active,
            "last_checked": self.last_checked.isoformat() if self.last_checked else None,
            "next_check": self.next_check.isoformat() if self.next_check else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# ============================================================
# Document Model
# ============================================================

class Document(db.Model):
    """Annual reports and corporate filings sourced via NSE MCP."""
    __tablename__ = "documents"

    id = db.Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    company_id = db.Column(UUID(as_uuid=False), db.ForeignKey("companies.id"), nullable=False)
    name = db.Column(db.String(500), nullable=False)
    document_type = db.Column(db.String(50), nullable=False)  # annual_report, corporate_filing
    report_year = db.Column(db.Integer, nullable=True)
    filing_date = db.Column(db.DateTime, nullable=True)
    s3_key = db.Column(db.String(500), nullable=True)
    s3_bucket = db.Column(db.String(100), nullable=True)
    file_size = db.Column(db.BigInteger, nullable=True)
    file_hash = db.Column(db.String(64), nullable=True)
    source_url = db.Column(db.String(1000), nullable=True)
    processing_status = db.Column(db.String(50), default="pending")  # pending, processing, completed, failed
    processing_error = db.Column(db.Text, nullable=True)
    vector_indexed = db.Column(db.Boolean, default=False)
    vector_count = db.Column(db.Integer, default=0)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    processed_at = db.Column(db.DateTime, nullable=True)
    nse_announcement_id = db.Column(db.String(100), nullable=True)
    meta_data = db.Column(JSONB, nullable=True)

    # Relationships
    chunks = db.relationship("Chunk", backref="document", lazy="dynamic", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_document_company_id", "company_id"),
        Index("ix_document_type", "document_type"),
        Index("ix_document_status", "processing_status"),
    )

    def __repr__(self):
        return f"<Document {self.name}>"

    def to_dict(self):
        return {
            "id": self.id,
            "company_id": self.company_id,
            "name": self.name,
            "document_type": self.document_type,
            "report_year": self.report_year,
            "filing_date": self.filing_date.isoformat() if self.filing_date else None,
            "s3_key": self.s3_key,
            "file_size": self.file_size,
            "processing_status": self.processing_status,
            "vector_indexed": self.vector_indexed,
            "vector_count": self.vector_count,
            "uploaded_at": self.uploaded_at.isoformat() if self.uploaded_at else None,
            "processed_at": self.processed_at.isoformat() if self.processed_at else None,
        }


# ============================================================
# Chunk Model
# ============================================================

class Chunk(db.Model):
    """Text chunks extracted from documents for RAG indexing."""
    __tablename__ = "chunks"

    id = db.Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    document_id = db.Column(UUID(as_uuid=False), db.ForeignKey("documents.id"), nullable=False)
    chunk_index = db.Column(db.Integer, nullable=False)
    text = db.Column(db.Text, nullable=False)
    page_number = db.Column(db.Integer, nullable=True)
    token_count = db.Column(db.Integer, nullable=True)
    vector_id = db.Column(db.String(255), nullable=True)  # Pinecone vector ID
    embedding_model = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    meta_data = db.Column(JSONB, nullable=True)

    __table_args__ = (
        Index("ix_chunk_document_id", "document_id"),
        Index("ix_chunk_vector_id", "vector_id"),
    )

    def __repr__(self):
        return f"<Chunk doc={self.document_id} idx={self.chunk_index}>"

    def to_dict(self):
        return {
            "id": self.id,
            "document_id": self.document_id,
            "chunk_index": self.chunk_index,
            "text": self.text[:200] + "..." if len(self.text) > 200 else self.text,
            "page_number": self.page_number,
            "token_count": self.token_count,
            "vector_id": self.vector_id,
        }


# ============================================================
# Analyst Report Model
# ============================================================

class AnalystReport(db.Model):
    """Manually uploaded analyst reports (buy/hold/sell) for demo dataset."""
    __tablename__ = "analyst_reports"

    id = db.Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    company_id = db.Column(UUID(as_uuid=False), db.ForeignKey("companies.id"), nullable=False)
    broker_name = db.Column(db.String(255), nullable=False)
    report_date = db.Column(db.DateTime, nullable=False)
    report_title = db.Column(db.String(500), nullable=True)
    rating = db.Column(db.String(20), nullable=True)  # buy, hold, sell, neutral
    target_price = db.Column(db.Numeric(12, 2), nullable=True)
    current_price = db.Column(db.Numeric(12, 2), nullable=True)
    s3_key = db.Column(db.String(500), nullable=True)
    s3_bucket = db.Column(db.String(100), nullable=True)
    file_size = db.Column(db.BigInteger, nullable=True)
    sentiment_processed = db.Column(db.Boolean, default=False)
    uploaded_by = db.Column(UUID(as_uuid=False), db.ForeignKey("users.id"), nullable=True)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    meta_data = db.Column(JSONB, nullable=True)

    __table_args__ = (
        Index("ix_analyst_report_company_id", "company_id"),
    )

    def __repr__(self):
        return f"<AnalystReport {self.broker_name} {self.company_id}>"

    def to_dict(self):
        return {
            "id": self.id,
            "company_id": self.company_id,
            "broker_name": self.broker_name,
            "report_date": self.report_date.isoformat() if self.report_date else None,
            "report_title": self.report_title,
            "rating": self.rating,
            "target_price": float(self.target_price) if self.target_price else None,
            "current_price": float(self.current_price) if self.current_price else None,
            "s3_key": self.s3_key,
            "sentiment_processed": self.sentiment_processed,
            "uploaded_at": self.uploaded_at.isoformat() if self.uploaded_at else None,
        }


# ============================================================
# Sentiment Score Model
# ============================================================

class SentimentScore(db.Model):
    """Aggregated sentiment scores from analyst reports per company."""
    __tablename__ = "sentiment_scores"

    id = db.Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    company_id = db.Column(UUID(as_uuid=False), db.ForeignKey("companies.id"), nullable=False)
    analyst_report_id = db.Column(UUID(as_uuid=False), db.ForeignKey("analyst_reports.id"), nullable=True)
    buy_count = db.Column(db.Integer, default=0)
    hold_count = db.Column(db.Integer, default=0)
    sell_count = db.Column(db.Integer, default=0)
    neutral_count = db.Column(db.Integer, default=0)
    sentiment_score = db.Column(db.Float, nullable=True)  # -1.0 (bearish) to 1.0 (bullish)
    sentiment_label = db.Column(db.String(20), nullable=True)  # bullish, bearish, neutral
    summary = db.Column(db.Text, nullable=True)
    period_start = db.Column(db.DateTime, nullable=True)
    period_end = db.Column(db.DateTime, nullable=True)
    computed_at = db.Column(db.DateTime, default=datetime.utcnow)
    meta_data = db.Column(JSONB, nullable=True)

    __table_args__ = (
        Index("ix_sentiment_company_id", "company_id"),
    )

    def __repr__(self):
        return f"<SentimentScore {self.company_id}>"

    def to_dict(self):
        return {
            "id": self.id,
            "company_id": self.company_id,
            "analyst_report_id": self.analyst_report_id,
            "buy_count": self.buy_count,
            "hold_count": self.hold_count,
            "sell_count": self.sell_count,
            "neutral_count": self.neutral_count,
            "sentiment_score": self.sentiment_score,
            "sentiment_label": self.sentiment_label,
            "summary": self.summary,
            "period_start": self.period_start.isoformat() if self.period_start else None,
            "period_end": self.period_end.isoformat() if self.period_end else None,
            "computed_at": self.computed_at.isoformat() if self.computed_at else None,
        }


# ============================================================
# Update Log Model
# ============================================================

class UpdateLog(db.Model):
    """Audit log for scheduler runs and document fetch operations."""
    __tablename__ = "update_logs"

    id = db.Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    company_id = db.Column(UUID(as_uuid=False), db.ForeignKey("companies.id"), nullable=True)
    log_type = db.Column(db.String(50), nullable=False)  # scheduler_run, mcp_fetch, rag_process, error
    status = db.Column(db.String(20), default="success")  # success, failed, partial
    message = db.Column(db.Text, nullable=True)
    documents_found = db.Column(db.Integer, default=0)
    documents_processed = db.Column(db.Integer, default=0)
    error_details = db.Column(JSONB, nullable=True)
    duration_ms = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_update_log_company_id", "company_id"),
        Index("ix_update_log_type", "log_type"),
        Index("ix_update_log_created_at", "created_at"),
    )

    def __repr__(self):
        return f"<UpdateLog {self.log_type} {self.status}>"

    def to_dict(self):
        return {
            "id": self.id,
            "company_id": self.company_id,
            "log_type": self.log_type,
            "status": self.status,
            "message": self.message,
            "documents_found": self.documents_found,
            "documents_processed": self.documents_processed,
            "duration_ms": self.duration_ms,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
