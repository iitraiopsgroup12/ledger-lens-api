"""LedgerLens.ai — Watchlist Blueprint"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from extensions import db
from models import Watchlist, Company
from datetime import datetime, timedelta
import structlog

watchlist_bp = Blueprint("watchlist", __name__)
logger = structlog.get_logger(__name__)

FREQUENCY_DELTAS = {
    "daily": timedelta(days=1),
    "weekly": timedelta(weeks=1),
    "monthly": timedelta(days=30),
    "manual": None,
}


@watchlist_bp.route("", methods=["GET"])
@jwt_required()
def get_watchlist():
    """GET /api/v1/watchlist — list current user's watchlist"""
    user_id = get_jwt_identity()
    items = Watchlist.query.filter_by(user_id=user_id, is_active=True).all()
    return jsonify({"watchlist": [w.to_dict() for w in items]}), 200


@watchlist_bp.route("", methods=["POST"])
@jwt_required()
def add_to_watchlist():
    """POST /api/v1/watchlist — add company to watchlist"""
    user_id = get_jwt_identity()
    data = request.get_json()
    symbol = data.get("symbol", "").upper().strip()
    frequency = data.get("update_frequency", "weekly")

    if not symbol:
        return jsonify({"error": "symbol is required"}), 400
    if frequency not in FREQUENCY_DELTAS:
        return jsonify({"error": f"update_frequency must be one of {list(FREQUENCY_DELTAS.keys())}"}), 400

    # Find or create company
    company = Company.query.filter_by(symbol=symbol).first()
    if not company:
        company = Company(symbol=symbol, name=data.get("name", symbol))
        db.session.add(company)
        db.session.flush()

    # Check existing watchlist entry
    existing = Watchlist.query.filter_by(user_id=user_id, company_id=company.id).first()
    if existing:
        if existing.is_active:
            return jsonify({"message": "Already in watchlist", "watchlist": existing.to_dict()}), 200
        existing.is_active = True
        existing.update_frequency = frequency
        db.session.commit()
        return jsonify({"watchlist": existing.to_dict()}), 200

    delta = FREQUENCY_DELTAS.get(frequency)
    now = datetime.utcnow()
    entry = Watchlist(
        user_id=user_id,
        company_id=company.id,
        update_frequency=frequency,
        next_check=now + delta if delta else None,
    )
    db.session.add(entry)
    db.session.commit()

    logger.info("watchlist_add", user_id=user_id, symbol=symbol)
    return jsonify({"watchlist": entry.to_dict()}), 201


@watchlist_bp.route("/<symbol>", methods=["DELETE"])
@jwt_required()
def remove_from_watchlist(symbol):
    """DELETE /api/v1/watchlist/<symbol>"""
    user_id = get_jwt_identity()
    company = Company.query.filter_by(symbol=symbol.upper()).first()
    if not company:
        return jsonify({"error": "Company not found"}), 404

    entry = Watchlist.query.filter_by(user_id=user_id, company_id=company.id, is_active=True).first()
    if not entry:
        return jsonify({"error": "Not in watchlist"}), 404

    entry.is_active = False
    db.session.commit()

    return jsonify({"message": f"{symbol} removed from watchlist"}), 200


@watchlist_bp.route("/<symbol>", methods=["PATCH"])
@jwt_required()
def update_watchlist_frequency(symbol):
    """PATCH /api/v1/watchlist/<symbol> — update frequency"""
    user_id = get_jwt_identity()
    data = request.get_json()
    frequency = data.get("update_frequency")

    if frequency not in FREQUENCY_DELTAS:
        return jsonify({"error": "Invalid frequency"}), 400

    company = Company.query.filter_by(symbol=symbol.upper()).first()
    if not company:
        return jsonify({"error": "Company not found"}), 404

    entry = Watchlist.query.filter_by(user_id=user_id, company_id=company.id, is_active=True).first()
    if not entry:
        return jsonify({"error": "Not in watchlist"}), 404

    entry.update_frequency = frequency
    delta = FREQUENCY_DELTAS.get(frequency)
    if delta:
        entry.next_check = datetime.utcnow() + delta
    db.session.commit()

    return jsonify({"watchlist": entry.to_dict()}), 200
