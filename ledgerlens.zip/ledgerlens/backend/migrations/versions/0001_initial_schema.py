"""Initial schema — users, companies, watchlists, documents, chunks, analyst_reports, sentiment_scores, update_logs

Revision ID: 0001_initial_schema
Revises:
Create Date: 2024-01-01 00:00:00

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # ── users ──────────────────────────────────────────────
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("email", sa.String(255), unique=True, nullable=False),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("full_name", sa.String(255), nullable=True),
        sa.Column("role", sa.String(50), default="analyst"),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("created_at", sa.DateTime, nullable=True),
        sa.Column("updated_at", sa.DateTime, nullable=True),
        sa.Column("last_login", sa.DateTime, nullable=True),
    )
    op.create_index("ix_users_email", "users", ["email"])

    # ── companies ──────────────────────────────────────────
    op.create_table(
        "companies",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("symbol", sa.String(20), unique=True, nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("isin", sa.String(20), nullable=True),
        sa.Column("sector", sa.String(100), nullable=True),
        sa.Column("industry", sa.String(100), nullable=True),
        sa.Column("market_cap", sa.Numeric(20, 2), nullable=True),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("website", sa.String(255), nullable=True),
        sa.Column("nse_series", sa.String(10), nullable=True),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("last_updated", sa.DateTime, nullable=True),
        sa.Column("created_at", sa.DateTime, nullable=True),
        sa.Column("meta_data", postgresql.JSONB, nullable=True),
    )
    op.create_index("ix_companies_symbol", "companies", ["symbol"])

    # ── watchlists ─────────────────────────────────────────
    op.create_table(
        "watchlists",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("company_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("update_frequency", sa.String(20), default="weekly"),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("last_checked", sa.DateTime, nullable=True),
        sa.Column("next_check", sa.DateTime, nullable=True),
        sa.Column("created_at", sa.DateTime, nullable=True),
        sa.Column("notes", sa.Text, nullable=True),
        sa.UniqueConstraint("user_id", "company_id", name="uq_user_company_watchlist"),
    )
    op.create_index("ix_watchlist_user_id", "watchlists", ["user_id"])
    op.create_index("ix_watchlist_company_id", "watchlists", ["company_id"])

    # ── documents ──────────────────────────────────────────
    op.create_table(
        "documents",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("company_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("name", sa.String(500), nullable=False),
        sa.Column("document_type", sa.String(50), nullable=False),
        sa.Column("report_year", sa.Integer, nullable=True),
        sa.Column("filing_date", sa.DateTime, nullable=True),
        sa.Column("s3_key", sa.String(500), nullable=True),
        sa.Column("s3_bucket", sa.String(100), nullable=True),
        sa.Column("file_size", sa.BigInteger, nullable=True),
        sa.Column("file_hash", sa.String(64), nullable=True),
        sa.Column("source_url", sa.String(1000), nullable=True),
        sa.Column("processing_status", sa.String(50), default="pending"),
        sa.Column("processing_error", sa.Text, nullable=True),
        sa.Column("vector_indexed", sa.Boolean, default=False),
        sa.Column("vector_count", sa.Integer, default=0),
        sa.Column("uploaded_at", sa.DateTime, nullable=True),
        sa.Column("processed_at", sa.DateTime, nullable=True),
        sa.Column("nse_announcement_id", sa.String(100), nullable=True),
        sa.Column("meta_data", postgresql.JSONB, nullable=True),
    )
    op.create_index("ix_document_company_id", "documents", ["company_id"])
    op.create_index("ix_document_type", "documents", ["document_type"])
    op.create_index("ix_document_status", "documents", ["processing_status"])

    # ── chunks ─────────────────────────────────────────────
    op.create_table(
        "chunks",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("document_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("documents.id"), nullable=False),
        sa.Column("chunk_index", sa.Integer, nullable=False),
        sa.Column("text", sa.Text, nullable=False),
        sa.Column("page_number", sa.Integer, nullable=True),
        sa.Column("token_count", sa.Integer, nullable=True),
        sa.Column("vector_id", sa.String(255), nullable=True),
        sa.Column("embedding_model", sa.String(100), nullable=True),
        sa.Column("created_at", sa.DateTime, nullable=True),
        sa.Column("meta_data", postgresql.JSONB, nullable=True),
    )
    op.create_index("ix_chunk_document_id", "chunks", ["document_id"])
    op.create_index("ix_chunk_vector_id", "chunks", ["vector_id"])

    # ── analyst_reports ────────────────────────────────────
    op.create_table(
        "analyst_reports",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("company_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("broker_name", sa.String(255), nullable=False),
        sa.Column("report_date", sa.DateTime, nullable=False),
        sa.Column("report_title", sa.String(500), nullable=True),
        sa.Column("rating", sa.String(20), nullable=True),
        sa.Column("target_price", sa.Numeric(12, 2), nullable=True),
        sa.Column("current_price", sa.Numeric(12, 2), nullable=True),
        sa.Column("s3_key", sa.String(500), nullable=True),
        sa.Column("s3_bucket", sa.String(100), nullable=True),
        sa.Column("file_size", sa.BigInteger, nullable=True),
        sa.Column("sentiment_processed", sa.Boolean, default=False),
        sa.Column("uploaded_by", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("uploaded_at", sa.DateTime, nullable=True),
        sa.Column("meta_data", postgresql.JSONB, nullable=True),
    )
    op.create_index("ix_analyst_report_company_id", "analyst_reports", ["company_id"])

    # ── sentiment_scores ───────────────────────────────────
    op.create_table(
        "sentiment_scores",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("company_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("analyst_report_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("analyst_reports.id"), nullable=True),
        sa.Column("buy_count", sa.Integer, default=0),
        sa.Column("hold_count", sa.Integer, default=0),
        sa.Column("sell_count", sa.Integer, default=0),
        sa.Column("neutral_count", sa.Integer, default=0),
        sa.Column("sentiment_score", sa.Float, nullable=True),
        sa.Column("sentiment_label", sa.String(20), nullable=True),
        sa.Column("summary", sa.Text, nullable=True),
        sa.Column("period_start", sa.DateTime, nullable=True),
        sa.Column("period_end", sa.DateTime, nullable=True),
        sa.Column("computed_at", sa.DateTime, nullable=True),
        sa.Column("meta_data", postgresql.JSONB, nullable=True),
    )
    op.create_index("ix_sentiment_company_id", "sentiment_scores", ["company_id"])

    # ── update_logs ────────────────────────────────────────
    op.create_table(
        "update_logs",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("company_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("companies.id"), nullable=True),
        sa.Column("log_type", sa.String(50), nullable=False),
        sa.Column("status", sa.String(20), default="success"),
        sa.Column("message", sa.Text, nullable=True),
        sa.Column("documents_found", sa.Integer, default=0),
        sa.Column("documents_processed", sa.Integer, default=0),
        sa.Column("error_details", postgresql.JSONB, nullable=True),
        sa.Column("duration_ms", sa.Integer, nullable=True),
        sa.Column("created_at", sa.DateTime, nullable=True),
    )
    op.create_index("ix_update_log_company_id", "update_logs", ["company_id"])
    op.create_index("ix_update_log_type", "update_logs", ["log_type"])
    op.create_index("ix_update_log_created_at", "update_logs", ["created_at"])


def downgrade():
    op.drop_table("update_logs")
    op.drop_table("sentiment_scores")
    op.drop_table("analyst_reports")
    op.drop_table("chunks")
    op.drop_table("documents")
    op.drop_table("watchlists")
    op.drop_table("companies")
    op.drop_table("users")
