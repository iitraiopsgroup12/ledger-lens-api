"""LedgerLens.ai — Scheduler Blueprint"""

from flask import Blueprint, jsonify, current_app
from flask_jwt_extended import jwt_required
from extensions import scheduler
import structlog

scheduler_bp = Blueprint("scheduler", __name__)
logger = structlog.get_logger(__name__)


@scheduler_bp.route("/run", methods=["POST"])
@jwt_required()
def run_scheduler():
    """POST /api/v1/scheduler/run — manually trigger the watchlist refresh job"""
    try:
        from services.scheduler_service import run_watchlist_refresh
        app = current_app._get_current_object()
        result = run_watchlist_refresh(app)
        return jsonify({"success": True, "result": result}), 200
    except Exception as e:
        logger.error("scheduler_manual_run_error", error=str(e))
        return jsonify({"success": False, "error": str(e)}), 500


@scheduler_bp.route("/status", methods=["GET"])
@jwt_required()
def scheduler_status():
    """GET /api/v1/scheduler/status — recent update logs"""
    from models import UpdateLog
    logs = UpdateLog.query.order_by(UpdateLog.created_at.desc()).limit(20).all()

    running = scheduler.running
    jobs = []
    for job in scheduler.get_jobs():
        jobs.append({
            "id": job.id,
            "name": job.name,
            "next_run": job.next_run_time.isoformat() if job.next_run_time else None,
        })

    return jsonify({
        "scheduler_running": running,
        "jobs": jobs,
        "recent_logs": [l.to_dict() for l in logs],
    }), 200
