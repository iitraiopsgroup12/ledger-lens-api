"""LedgerLens.ai — RAG Blueprint"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from extensions import db
from models import Document, Chunk
from services.s3_service import s3_service
from services.extraction_service import extraction_service
from services.chunking_service import chunking_service
from services.embedding_service import embedding_service
from services.pinecone_service import pinecone_service
from datetime import datetime
import structlog

rag_bp = Blueprint("rag", __name__)
logger = structlog.get_logger(__name__)


@rag_bp.route("/process/<document_id>", methods=["POST"])
@jwt_required()
def process_document(document_id):
    """Trigger RAG processing pipeline for a document."""
    doc = Document.query.get(document_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    if doc.processing_status == "completed":
        return jsonify({"message": "Document already processed"}), 200

    doc.processing_status = "processing"
    db.session.commit()

    try:
        # 1. Download from S3
        if not doc.s3_key:
            return jsonify({"error": "No S3 key found for document"}), 400
        pdf_bytes = s3_service.download_file(doc.s3_key)
        if not pdf_bytes:
            raise Exception("Failed to download PDF from S3")

        # 2. Extract text
        extracted = extraction_service.extract_from_bytes(pdf_bytes)

        # 3. Chunk
        chunks = chunking_service.chunk_pages(
            extracted.get("pages", [{"page_number": 1, "text": extracted.get("full_text", "")}])
        )

        # 4. Embed and store in Pinecone
        company = doc.company
        vectors = []
        db_chunks = []

        for chunk_data in chunks:
            embedding = embedding_service.embed_text(chunk_data["text"])
            vector_id = f"{doc.id}_{chunk_data['chunk_index']}"

            vectors.append({
                "id": vector_id,
                "values": embedding,
                "metadata": {
                    "document_id": doc.id,
                    "company_id": str(doc.company_id),
                    "symbol": company.symbol if company else "",
                    "document_name": doc.name,
                    "document_type": doc.document_type,
                    "report_year": doc.report_year,
                    "text": chunk_data["text"][:500],
                    "page_number": chunk_data.get("page_number", 0),
                },
            })

            db_chunks.append(Chunk(
                document_id=doc.id,
                chunk_index=chunk_data["chunk_index"],
                text=chunk_data["text"],
                page_number=chunk_data.get("page_number"),
                token_count=chunk_data.get("token_count"),
                vector_id=vector_id,
                embedding_model="gemini-embedding-001",
            ))

        # 5. Upsert to Pinecone
        result = pinecone_service.upsert_vectors(vectors)

        # 6. Save chunks to DB
        for c in db_chunks:
            db.session.add(c)

        doc.processing_status = "completed"
        doc.vector_indexed = True
        doc.vector_count = len(vectors)
        doc.processed_at = datetime.utcnow()
        db.session.commit()

        logger.info("rag_process_complete", doc_id=doc.id, chunks=len(vectors))
        return jsonify({"success": True, "document_id": doc.id, "chunks_indexed": len(vectors)}), 200

    except Exception as e:
        doc.processing_status = "failed"
        doc.processing_error = str(e)
        db.session.commit()
        logger.error("rag_process_error", doc_id=doc.id, error=str(e))
        return jsonify({"error": str(e)}), 500


@rag_bp.route("/status/<document_id>", methods=["GET"])
@jwt_required()
def rag_status(document_id):
    doc = Document.query.get(document_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    return jsonify({
        "document_id": doc.id,
        "processing_status": doc.processing_status,
        "vector_indexed": doc.vector_indexed,
        "vector_count": doc.vector_count,
        "processed_at": doc.processed_at.isoformat() if doc.processed_at else None,
        "error": doc.processing_error,
    }), 200
