"""
LedgerLens.ai — LangGraph RAG Workflow
Routes queries through retrieve → generate pipeline with multi-company support.
"""

import structlog
from typing import TypedDict, List, Optional, Annotated
from langgraph.graph import StateGraph, END

logger = structlog.get_logger(__name__)


# ─── State ────────────────────────────────────────────────────────────────────

class RAGState(TypedDict):
    query: str
    symbols: List[str]
    query_type: str          # summary|analysis|risk|growth|comparison
    retrieved_chunks: List[dict]
    answer: str
    sources: List[dict]
    error: Optional[str]


# ─── Nodes ────────────────────────────────────────────────────────────────────

def classify_query(state: RAGState) -> RAGState:
    """Classify the query type to guide retrieval."""
    query = state["query"].lower()
    if any(w in query for w in ["compar", "vs", "versus", "both", "between"]):
        state["query_type"] = "comparison"
    elif any(w in query for w in ["risk", "threat", "challenge", "concern"]):
        state["query_type"] = "risk"
    elif any(w in query for w in ["growth", "strategy", "expansion", "plan"]):
        state["query_type"] = "growth"
    elif any(w in query for w in ["summary", "overview", "about", "describe"]):
        state["query_type"] = "summary"
    else:
        state["query_type"] = "analysis"
    logger.info("query_classified", query_type=state["query_type"])
    return state


def retrieve_context(state: RAGState) -> RAGState:
    """Retrieve relevant chunks from Pinecone for all relevant symbols."""
    from flask import current_app
    from services.embedding_service import embedding_service
    from services.pinecone_service import pinecone_service

    try:
        query_embedding = embedding_service.embed_query(state["query"])
        all_chunks = []

        symbols = state.get("symbols", [])
        if symbols:
            for symbol in symbols:
                filter_dict = {"symbol": symbol.upper()}
                chunks = pinecone_service.query(query_embedding, top_k=5, filter=filter_dict)
                all_chunks.extend(chunks)
        else:
            all_chunks = pinecone_service.query(query_embedding, top_k=10)

        # Sort by score descending
        all_chunks.sort(key=lambda x: x.get("score", 0), reverse=True)
        state["retrieved_chunks"] = all_chunks[:12]
        logger.info("retrieval_complete", chunks_found=len(state["retrieved_chunks"]))
    except Exception as e:
        logger.error("retrieval_error", error=str(e))
        state["retrieved_chunks"] = []
        state["error"] = str(e)

    return state


def generate_answer(state: RAGState) -> RAGState:
    """Generate final answer using Gemini with retrieved context."""
    from services.gemini_service import gemini_service

    chunks = state["retrieved_chunks"]
    query_type = state["query_type"]

    system_prompts = {
        "comparison": "You are a senior equity analyst. Compare the companies objectively using data from their annual reports. Structure your answer with clear sections.",
        "risk": "You are a risk analyst. Identify and categorize key risks mentioned in the annual reports. Be specific and cite the source document.",
        "growth": "You are a growth strategy analyst. Summarize growth strategies, expansion plans, and management outlook from the annual reports.",
        "summary": "You are a financial analyst. Provide a clear executive summary based on the annual report content.",
        "analysis": "You are a financial analyst. Provide a detailed analysis based on the annual report content. Be specific, factual, and structured.",
    }

    system_prompt = system_prompts.get(query_type, system_prompts["analysis"])
    context_texts = [{"text": c.get("metadata", {}).get("text", "") or c.get("text", "")} for c in chunks]

    if not any(c["text"] for c in context_texts):
        state["answer"] = "I don't have enough information in the knowledge base to answer this question. Please ensure annual reports have been processed for the relevant companies."
        state["sources"] = []
        return state

    answer = gemini_service.generate_with_context(state["query"], context_texts, system_prompt)
    state["answer"] = answer

    # Build sources list (deduplicated)
    seen = set()
    sources = []
    for c in chunks:
        meta = c.get("metadata", {})
        src_key = f"{meta.get('symbol')}_{meta.get('document_id')}"
        if src_key not in seen:
            seen.add(src_key)
            sources.append({
                "symbol": meta.get("symbol"),
                "document_name": meta.get("document_name"),
                "document_type": meta.get("document_type"),
                "report_year": meta.get("report_year"),
                "relevance_score": round(c.get("score", 0), 4),
            })
    state["sources"] = sources

    return state


def handle_error(state: RAGState) -> RAGState:
    state["answer"] = "An error occurred while processing your query. Please try again."
    state["sources"] = []
    return state


# ─── Graph Assembly ───────────────────────────────────────────────────────────

def build_rag_graph():
    graph = StateGraph(RAGState)

    graph.add_node("classify_query", classify_query)
    graph.add_node("retrieve_context", retrieve_context)
    graph.add_node("generate_answer", generate_answer)
    graph.add_node("handle_error", handle_error)

    graph.set_entry_point("classify_query")
    graph.add_edge("classify_query", "retrieve_context")

    graph.add_conditional_edges(
        "retrieve_context",
        lambda s: "handle_error" if s.get("error") else "generate_answer",
        {"handle_error": "handle_error", "generate_answer": "generate_answer"},
    )

    graph.add_edge("generate_answer", END)
    graph.add_edge("handle_error", END)

    return graph.compile()


# Singleton compiled graph
_rag_graph = None


def get_rag_graph():
    global _rag_graph
    if _rag_graph is None:
        _rag_graph = build_rag_graph()
    return _rag_graph


def run_rag_query(query: str, symbols: List[str] = None) -> dict:
    """Public entry point: run a RAG query and return answer + sources."""
    graph = get_rag_graph()
    initial_state = RAGState(
        query=query,
        symbols=symbols or [],
        query_type="analysis",
        retrieved_chunks=[],
        answer="",
        sources=[],
        error=None,
    )
    result = graph.invoke(initial_state)
    return {
        "answer": result["answer"],
        "sources": result["sources"],
        "query_type": result["query_type"],
    }
