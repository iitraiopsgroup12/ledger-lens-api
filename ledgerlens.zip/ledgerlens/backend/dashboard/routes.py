"""LedgerLens.ai — Dashboard Blueprint"""

from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import Watchlist, Document, UpdateLog, Company
from extensions import db
from sqlalchemy import func
import structlog

dashboard_bp = Blueprint("dashboard", __name__)
logger = structlog.get_logger(__name__)


@dashboard_bp.route("", methods=["GET"])
@jwt_required()
def get_dashboard():
    """GET /api/v1/dashboard — aggregated stats for current user"""
    user_id = get_jwt_identity()

    # Watchlist count
    watchlist_count = Watchlist.query.filter_by(user_id=user_id, is_active=True).count()

    # Company IDs in watchlist
    wl_items = Watchlist.query.filter_by(user_id=user_id, is_active=True).all()
    company_ids = [w.company_id for w in wl_items]

    # New reports (last 7 days)
    from datetime import datetime, timedelta
    cutoff = datetime.utcnow() - timedelta(days=7)
    new_reports = Document.query.filter(
        Document.company_id.in_(company_ids),
        Document.uploaded_at >= cutoff,
    ).count() if company_ids else 0

    # Pending processing
    pending = Document.query.filter(
        Document.company_id.in_(company_ids),
        Document.processing_status.in_(["pending", "downloaded"]),
    ).count() if company_ids else 0

    # Recent updates table
    recent_docs = Document.query.filter(
        Document.company_id.in_(company_ids)
    ).order_by(Document.uploaded_at.desc()).limit(10).all() if company_ids else []

    recent_updates = []
    for doc in recent_docs:
        company = Company.query.get(doc.company_id)
        recent_updates.append({
            "company": company.name if company else "Unknown",
            "symbol": company.symbol if company else "",
            "last_update": doc.uploaded_at.isoformat() if doc.uploaded_at else None,
            "latest_report": doc.name,
            "status": doc.processing_status,
        })

    return jsonify({
        "stats": {
            "watchlist_companies": watchlist_count,
            "new_reports": new_reports,
            "pending_processing": pending,
        },
        "recent_updates": recent_updates,
    }), 200
