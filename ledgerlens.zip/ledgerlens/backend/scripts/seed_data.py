"""
LedgerLens.ai — Seed Script
Populates the database with demo companies and a demo user for the MVP.

Usage:
    python scripts/seed_data.py
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app import create_app
from extensions import db
from models import User, Company
from werkzeug.security import generate_password_hash

DEMO_COMPANIES = [
    {"symbol": "TCS", "name": "Tata Consultancy Services Ltd", "sector": "Information Technology", "industry": "IT Services & Consulting"},
    {"symbol": "INFY", "name": "Infosys Ltd", "sector": "Information Technology", "industry": "IT Services & Consulting"},
    {"symbol": "WIPRO", "name": "Wipro Ltd", "sector": "Information Technology", "industry": "IT Services & Consulting"},
    {"symbol": "HDFCBANK", "name": "HDFC Bank Ltd", "sector": "Financial Services", "industry": "Private Sector Bank"},
]


def seed():
    app = create_app()
    with app.app_context():
        # Demo user
        if not User.query.filter_by(email="analyst@ledgerlens.ai").first():
            user = User(
                email="analyst@ledgerlens.ai",
                password_hash=generate_password_hash("LedgerLens@2024"),
                full_name="Demo Analyst",
                role="analyst",
            )
            db.session.add(user)
            print("Created demo user: analyst@ledgerlens.ai / LedgerLens@2024")

        # Demo companies
        for c in DEMO_COMPANIES:
            if not Company.query.filter_by(symbol=c["symbol"]).first():
                db.session.add(Company(**c))
                print(f"Created company: {c['symbol']} — {c['name']}")

        db.session.commit()
        print("Seed complete.")


if __name__ == "__main__":
    seed()
