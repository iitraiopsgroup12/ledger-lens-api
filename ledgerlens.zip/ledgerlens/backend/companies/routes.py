"""LedgerLens.ai — Companies Blueprint"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from extensions import db
from models import Company, Document, AnalystReport
import structlog

companies_bp = Blueprint("companies", __name__)
logger = structlog.get_logger(__name__)


@companies_bp.route("/search", methods=["GET"])
@jwt_required()
def search_companies():
    """GET /api/v1/companies/search?q=TCS"""
    q = request.args.get("q", "").strip()
    if not q or len(q) < 2:
        return jsonify({"error": "Query must be at least 2 characters"}), 400

    companies = Company.query.filter(
        (Company.symbol.ilike(f"%{q}%")) | (Company.name.ilike(f"%{q}%"))
    ).filter_by(is_active=True).limit(20).all()

    return jsonify({"companies": [c.to_dict() for c in companies]}), 200


@companies_bp.route("/<symbol>", methods=["GET"])
@jwt_required()
def get_company(symbol):
    """GET /api/v1/companies/<symbol>"""
    company = Company.query.filter_by(symbol=symbol.upper()).first()
    if not company:
        return jsonify({"error": "Company not found"}), 404

    annual_reports = Document.query.filter_by(
        company_id=company.id, document_type="annual_report"
    ).count()
    filings = Document.query.filter_by(
        company_id=company.id, document_type="corporate_filing"
    ).count()
    analyst_count = AnalystReport.query.filter_by(company_id=company.id).count()

    data = company.to_dict()
    data["stats"] = {
        "annual_reports": annual_reports,
        "corporate_filings": filings,
        "analyst_reports": analyst_count,
    }
    return jsonify({"company": data}), 200


@companies_bp.route("/<symbol>/documents", methods=["GET"])
@jwt_required()
def get_company_documents(symbol):
    """GET /api/v1/companies/<symbol>/documents"""
    company = Company.query.filter_by(symbol=symbol.upper()).first()
    if not company:
        return jsonify({"error": "Company not found"}), 404

    doc_type = request.args.get("type")
    query = Document.query.filter_by(company_id=company.id)
    if doc_type:
        query = query.filter_by(document_type=doc_type)
    documents = query.order_by(Document.filing_date.desc()).all()

    return jsonify({"documents": [d.to_dict() for d in documents]}), 200


@companies_bp.route("/<symbol>/analyst-reports", methods=["GET"])
@jwt_required()
def get_company_analyst_reports(symbol):
    """GET /api/v1/companies/<symbol>/analyst-reports"""
    company = Company.query.filter_by(symbol=symbol.upper()).first()
    if not company:
        return jsonify({"error": "Company not found"}), 404

    reports = AnalystReport.query.filter_by(company_id=company.id)\
        .order_by(AnalystReport.report_date.desc()).all()

    return jsonify({"analyst_reports": [r.to_dict() for r in reports]}), 200


@companies_bp.route("/<symbol>/sentiment", methods=["GET"])
@jwt_required()
def get_company_sentiment(symbol):
    """GET /api/v1/companies/<symbol>/sentiment"""
    from models import SentimentScore
    company = Company.query.filter_by(symbol=symbol.upper()).first()
    if not company:
        return jsonify({"error": "Company not found"}), 404

    scores = SentimentScore.query.filter_by(company_id=company.id)\
        .order_by(SentimentScore.computed_at.desc()).all()

    if not scores:
        return jsonify({"symbol": symbol, "sentiment": None, "message": "No sentiment data available"}), 200

    latest = scores[0]
    return jsonify({
        "symbol": symbol,
        "sentiment": latest.to_dict(),
        "history": [s.to_dict() for s in scores[:10]],
    }), 200


@companies_bp.route("", methods=["POST"])
@jwt_required()
def create_company():
    """Create/register a new company (auto-created when added to watchlist)."""
    data = request.get_json()
    symbol = data.get("symbol", "").upper().strip()
    name = data.get("name", "").strip()

    if not symbol or not name:
        return jsonify({"error": "symbol and name are required"}), 400

    existing = Company.query.filter_by(symbol=symbol).first()
    if existing:
        return jsonify({"company": existing.to_dict()}), 200

    company = Company(symbol=symbol, name=name, sector=data.get("sector"), industry=data.get("industry"))
    db.session.add(company)
    db.session.commit()

    return jsonify({"company": company.to_dict()}), 201
