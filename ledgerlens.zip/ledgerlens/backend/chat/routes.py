"""LedgerLens.ai — Chat Blueprint"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
import re, structlog

chat_bp = Blueprint("chat", __name__)
logger = structlog.get_logger(__name__)


def _extract_symbols(query: str) -> list:
    """Heuristically extract NSE symbols from query text."""
    from models import Company
    # Look for uppercase words 2-10 chars as potential symbols
    candidates = re.findall(r"\b[A-Z]{2,10}\b", query)
    symbols = []
    for c in candidates:
        company = Company.query.filter_by(symbol=c).first()
        if company:
            symbols.append(c)
    return symbols


@chat_bp.route("", methods=["POST"])
@jwt_required()
def chat():
    """
    Main chat endpoint. Accepts natural language query and returns AI answer.
    POST /api/v1/chat
    Body: {"query": "...", "symbols": ["TCS", "INFY"]}  (symbols optional)
    """
    data = request.get_json()
    if not data or not data.get("query"):
        return jsonify({"error": "query is required"}), 400

    query = data["query"].strip()
    symbols = data.get("symbols") or _extract_symbols(query)

    try:
        from rag.workflow import run_rag_query
        result = run_rag_query(query, symbols)
        return jsonify({
            "answer": result["answer"],
            "sources": result["sources"],
            "query_type": result["query_type"],
            "symbols_used": symbols,
        }), 200
    except Exception as e:
        logger.error("chat_error", error=str(e))
        return jsonify({"error": "Failed to process query", "details": str(e)}), 500
