"""LedgerLens.ai — Compare Blueprint"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
import structlog

compare_bp = Blueprint("compare", __name__)
logger = structlog.get_logger(__name__)

# Note: compare is handled inline by the chat/RAG system with a comparison query type.
# This file exposes /api/v1/compare as a dedicated endpoint for the compare page.


@compare_bp.route("", methods=["POST"])
@jwt_required()
def compare():
    """
    POST /api/v1/compare
    Body: {"symbols": ["TCS","INFY","WIPRO"], "dimension": "growth_strategy"}
    Dimensions: growth_strategy, risks, management_outlook, capital_allocation, expansion_plans
    """
    data = request.get_json()
    symbols = data.get("symbols", [])
    dimension = data.get("dimension", "growth_strategy")

    if len(symbols) < 2:
        return jsonify({"error": "At least 2 symbols are required for comparison"}), 400
    if len(symbols) > 5:
        return jsonify({"error": "Maximum 5 companies can be compared"}), 400

    dimension_prompts = {
        "growth_strategy": "Compare the growth strategy and future plans",
        "risks": "Compare the key risks and risk mitigation strategies",
        "management_outlook": "Compare management outlook and guidance for the next year",
        "capital_allocation": "Compare capital allocation, CAPEX plans, and dividend policy",
        "expansion_plans": "Compare geographical and business expansion plans",
    }

    symbol_list = ", ".join(symbols)
    prompt_fragment = dimension_prompts.get(dimension, "Compare overall business performance")
    query = f"{prompt_fragment} for {symbol_list}. Provide a structured comparison with a section for each company, then a summary table."

    try:
        from rag.workflow import run_rag_query
        result = run_rag_query(query, symbols)
        return jsonify({
            "symbols": symbols,
            "dimension": dimension,
            "answer": result["answer"],
            "sources": result["sources"],
        }), 200
    except Exception as e:
        logger.error("compare_error", error=str(e))
        return jsonify({"error": str(e)}), 500
