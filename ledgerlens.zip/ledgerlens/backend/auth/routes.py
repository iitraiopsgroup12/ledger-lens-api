"""
LedgerLens.ai — Authentication Blueprint
Handles user login and JWT token management.
"""

from datetime import datetime
from flask import Blueprint, request, jsonify
from flask_jwt_extended import (
    create_access_token,
    jwt_required,
    get_jwt_identity,
)
from werkzeug.security import check_password_hash, generate_password_hash
from extensions import db
from models import User
import structlog

auth_bp = Blueprint("auth", __name__)
logger = structlog.get_logger(__name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    """
    Authenticate user and return JWT token.
    ---
    tags: [Authentication]
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "Request body is required"}), 400

    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400

    user = User.query.filter_by(email=email, is_active=True).first()

    if not user or not check_password_hash(user.password_hash, password):
        logger.warning("failed_login_attempt", email=email)
        return jsonify({"error": "Invalid email or password"}), 401

    # Update last login
    user.last_login = datetime.utcnow()
    db.session.commit()

    access_token = create_access_token(identity=user.id)

    logger.info("user_logged_in", user_id=user.id, email=email)

    return jsonify({
        "access_token": access_token,
        "token_type": "Bearer",
        "user": user.to_dict(),
    }), 200


@auth_bp.route("/profile", methods=["GET"])
@jwt_required()
def profile():
    """
    Get current authenticated user's profile.
    ---
    tags: [Authentication]
    """
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    if not user:
        return jsonify({"error": "User not found"}), 404

    return jsonify({"user": user.to_dict()}), 200


@auth_bp.route("/seed-demo-user", methods=["POST"])
def seed_demo_user():
    """
    Create a demo user for testing (development only).
    """
    import os
    if os.environ.get("FLASK_ENV") == "production":
        return jsonify({"error": "Not available in production"}), 403

    existing = User.query.filter_by(email="analyst@ledgerlens.ai").first()
    if existing:
        return jsonify({"message": "Demo user already exists", "email": "analyst@ledgerlens.ai"}), 200

    demo_user = User(
        email="analyst@ledgerlens.ai",
        password_hash=generate_password_hash("LedgerLens@2024"),
        full_name="Demo Analyst",
        role="analyst",
        is_active=True,
    )
    db.session.add(demo_user)
    db.session.commit()

    return jsonify({
        "message": "Demo user created",
        "email": "analyst@ledgerlens.ai",
        "password": "LedgerLens@2024",
    }), 201
