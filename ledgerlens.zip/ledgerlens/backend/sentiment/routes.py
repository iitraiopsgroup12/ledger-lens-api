"""LedgerLens.ai — Sentiment Blueprint"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from extensions import db
from models import AnalystReport, SentimentScore, Company
from services.gemini_service import gemini_service
from services.s3_service import s3_service
from datetime import datetime
import structlog

sentiment_bp = Blueprint("sentiment", __name__)
logger = structlog.get_logger(__name__)


def _compute_sentiment_score(buy: int, hold: int, sell: int, neutral: int) -> float:
    """Compute a numeric sentiment score from rating counts."""
    total = buy + hold + sell + neutral
    if total == 0:
        return 0.0
    return round((buy * 1.0 + hold * 0.0 + sell * -1.0 + neutral * 0.0) / total, 4)


@sentiment_bp.route("/companies/<symbol>/sentiment", methods=["GET"])
@jwt_required()
def get_sentiment(symbol):
    company = Company.query.filter_by(symbol=symbol.upper()).first()
    if not company:
        return jsonify({"error": "Company not found"}), 404

    reports = AnalystReport.query.filter_by(company_id=company.id).all()
    if not reports:
        return jsonify({"symbol": symbol, "sentiment": None, "message": "No analyst reports"}), 200

    buy_count = sum(1 for r in reports if r.rating == "buy")
    hold_count = sum(1 for r in reports if r.rating == "hold")
    sell_count = sum(1 for r in reports if r.rating == "sell")
    neutral_count = sum(1 for r in reports if r.rating in ("neutral", None))
    score = _compute_sentiment_score(buy_count, hold_count, sell_count, neutral_count)

    if score > 0.3:
        label = "bullish"
    elif score < -0.3:
        label = "bearish"
    else:
        label = "neutral"

    return jsonify({
        "symbol": symbol,
        "sentiment": {
            "buy_count": buy_count,
            "hold_count": hold_count,
            "sell_count": sell_count,
            "neutral_count": neutral_count,
            "sentiment_score": score,
            "sentiment_label": label,
            "total_reports": len(reports),
        }
    }), 200


@sentiment_bp.route("/analyst-reports/<report_id>/analyze", methods=["POST"])
@jwt_required()
def analyze_report_sentiment(report_id):
    """Trigger Gemini sentiment analysis on a manually uploaded analyst report."""
    report = AnalystReport.query.get(report_id)
    if not report:
        return jsonify({"error": "Report not found"}), 404

    if not report.s3_key:
        return jsonify({"error": "No PDF file to analyze"}), 400

    # Download PDF from S3
    pdf_bytes = s3_service.download_file(report.s3_key)
    if not pdf_bytes:
        return jsonify({"error": "Could not download report from S3"}), 500

    # Extract text
    from services.extraction_service import extraction_service
    extracted = extraction_service.extract_from_bytes(pdf_bytes)
    text = extracted.get("full_text", "")[:5000]

    if not text.strip():
        return jsonify({"error": "Could not extract text from PDF"}), 400

    # Gemini sentiment analysis
    analysis = gemini_service.analyze_sentiment(text)

    # Update report with AI-detected rating if not set
    if not report.rating and analysis.get("rating"):
        report.rating = analysis["rating"]
    report.sentiment_processed = True
    db.session.commit()

    # Store sentiment score
    company = report.company
    score_value = analysis.get("sentiment_score", 0.0)
    label = "bullish" if score_value > 0.3 else "bearish" if score_value < -0.3 else "neutral"

    sentiment = SentimentScore(
        company_id=company.id,
        analyst_report_id=report.id,
        buy_count=1 if analysis.get("rating") == "buy" else 0,
        hold_count=1 if analysis.get("rating") == "hold" else 0,
        sell_count=1 if analysis.get("rating") == "sell" else 0,
        neutral_count=1 if analysis.get("rating") in ("neutral", None) else 0,
        sentiment_score=score_value,
        sentiment_label=label,
        summary=analysis.get("summary"),
        computed_at=datetime.utcnow(),
        meta_data={"key_points": analysis.get("key_points", [])},
    )
    db.session.add(sentiment)
    db.session.commit()

    return jsonify({
        "report_id": report.id,
        "analysis": analysis,
        "sentiment_id": sentiment.id,
    }), 200
