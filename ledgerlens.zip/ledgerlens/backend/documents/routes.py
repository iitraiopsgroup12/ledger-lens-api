"""LedgerLens.ai — Documents Blueprint"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from extensions import db
from models import Document
from services.s3_service import s3_service
import structlog

documents_bp = Blueprint("documents", __name__)
logger = structlog.get_logger(__name__)


@documents_bp.route("/<document_id>", methods=["GET"])
@jwt_required()
def get_document(document_id):
    """GET /api/v1/documents/<id>"""
    doc = Document.query.get(document_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    return jsonify({"document": doc.to_dict()}), 200


@documents_bp.route("/<document_id>/download", methods=["GET"])
@jwt_required()
def download_document(document_id):
    """GET /api/v1/documents/<id>/download — returns S3 presigned URL"""
    doc = Document.query.get(document_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    if not doc.s3_key:
        return jsonify({"error": "No file available for this document"}), 404

    url = s3_service.get_presigned_url(doc.s3_key)
    if not url:
        return jsonify({"error": "Could not generate download URL"}), 500

    return jsonify({"download_url": url, "expires_in": 3600}), 200


@documents_bp.route("", methods=["GET"])
@jwt_required()
def list_documents():
    """GET /api/v1/documents — paginated document list"""
    page = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 20))
    doc_type = request.args.get("type")
    symbol = request.args.get("symbol")

    from models import Company
    query = Document.query
    if doc_type:
        query = query.filter_by(document_type=doc_type)
    if symbol:
        company = Company.query.filter_by(symbol=symbol.upper()).first()
        if company:
            query = query.filter_by(company_id=company.id)

    paginated = query.order_by(Document.uploaded_at.desc()).paginate(page=page, per_page=per_page)

    return jsonify({
        "documents": [d.to_dict() for d in paginated.items],
        "total": paginated.total,
        "page": page,
        "pages": paginated.pages,
    }), 200
