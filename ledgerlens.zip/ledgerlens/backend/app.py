"""
LedgerLens.ai — Application Factory
Creates and configures the Flask application.
"""

import os
import structlog
from flask import Flask, jsonify
from flask_swagger_ui import get_swaggerui_blueprint

from config import get_config
from extensions import db, jwt, migrate, cors, ma


def create_app(config_class=None):
    """Application factory pattern."""
    app = Flask(__name__, static_folder="../frontend", static_url_path="")

    # Load configuration
    if config_class is None:
        config_class = get_config()
    app.config.from_object(config_class)

    # Configure structured logging
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_log_level,
            structlog.stdlib.add_logger_name,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
    )

    # Initialize extensions
    db.init_app(app)
    jwt.init_app(app)
    migrate.init_app(app, db)
    cors.init_app(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}})
    ma.init_app(app)

    # Register all blueprints
    _register_blueprints(app)

    # Register Swagger UI
    _register_swagger(app)

    # Register error handlers
    _register_error_handlers(app)

    # Start scheduler (skip during testing/migrations)
    if not app.config.get("TESTING") and os.environ.get("ENABLE_SCHEDULER", "true").lower() == "true":
        _start_scheduler(app)

    # Health check
    @app.route("/health")
    def health():
        return jsonify({"status": "healthy", "service": "LedgerLens.ai"})

    # Frontend catch-all (serve HTML pages)
    @app.route("/")
    def index():
        return app.send_static_file("login.html")

    @app.route("/<path:path>")
    def static_files(path):
        try:
            return app.send_static_file(path)
        except Exception:
            return app.send_static_file("login.html")

    return app


def _register_blueprints(app):
    """Register all Flask Blueprints."""
    from auth.routes import auth_bp
    from users.routes import users_bp
    from companies.routes import companies_bp
    from watchlist.routes import watchlist_bp
    from documents.routes import documents_bp
    from rag.routes import rag_bp
    from chat.routes import chat_bp
    from sentiment.routes import sentiment_bp
    from scheduler.routes import scheduler_bp
    from dashboard.routes import dashboard_bp
    from mcp.routes import mcp_bp
    from analyst_reports.routes import analyst_reports_bp
    from chat.compare import compare_bp

    app.register_blueprint(auth_bp, url_prefix="/api/v1/auth")
    app.register_blueprint(users_bp, url_prefix="/api/v1/users")
    app.register_blueprint(companies_bp, url_prefix="/api/v1/companies")
    app.register_blueprint(watchlist_bp, url_prefix="/api/v1/watchlist")
    app.register_blueprint(documents_bp, url_prefix="/api/v1/documents")
    app.register_blueprint(rag_bp, url_prefix="/api/v1/rag")
    app.register_blueprint(chat_bp, url_prefix="/api/v1/chat")
    app.register_blueprint(sentiment_bp, url_prefix="/api/v1")
    app.register_blueprint(scheduler_bp, url_prefix="/api/v1/scheduler")
    app.register_blueprint(dashboard_bp, url_prefix="/api/v1/dashboard")
    app.register_blueprint(mcp_bp, url_prefix="/api/v1/mcp")
    app.register_blueprint(analyst_reports_bp, url_prefix="/api/v1/analyst-reports")
    app.register_blueprint(compare_bp, url_prefix="/api/v1/compare")


def _register_swagger(app):
    """Register Swagger UI blueprint."""
    SWAGGER_URL = "/api/docs"
    API_URL = "/static/swagger.json"
    swaggerui_bp = get_swaggerui_blueprint(
        SWAGGER_URL,
        API_URL,
        config={"app_name": "LedgerLens.ai API"},
    )
    app.register_blueprint(swaggerui_bp, url_prefix=SWAGGER_URL)


def _register_error_handlers(app):
    """Register global error handlers."""

    @app.errorhandler(400)
    def bad_request(e):
        return jsonify({"error": "Bad Request", "message": str(e)}), 400

    @app.errorhandler(401)
    def unauthorized(e):
        return jsonify({"error": "Unauthorized", "message": "Authentication required"}), 401

    @app.errorhandler(403)
    def forbidden(e):
        return jsonify({"error": "Forbidden", "message": "Access denied"}), 403

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Not Found", "message": str(e)}), 404

    @app.errorhandler(500)
    def internal_error(e):
        return jsonify({"error": "Internal Server Error", "message": "An unexpected error occurred"}), 500

    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return jsonify({"error": "Token Expired", "message": "JWT token has expired"}), 401

    @jwt.invalid_token_loader
    def invalid_token_callback(error):
        return jsonify({"error": "Invalid Token", "message": str(error)}), 401

    @jwt.unauthorized_loader
    def missing_token_callback(error):
        return jsonify({"error": "Unauthorized", "message": "JWT token is missing"}), 401


def _start_scheduler(app):
    """Start APScheduler with the watchlist refresh job."""
    from extensions import scheduler
    from services.scheduler_service import run_watchlist_refresh

    if not scheduler.running:
        scheduler.add_job(
            id="watchlist_refresh",
            func=run_watchlist_refresh,
            args=[app],
            trigger="interval",
            hours=6,
            replace_existing=True,
        )
        scheduler.start()


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=True)
