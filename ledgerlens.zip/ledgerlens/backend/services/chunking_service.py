"""
LedgerLens.ai — Text Chunking Service
Splits extracted text into overlapping chunks for RAG indexing.
"""

import structlog
from typing import List
from flask import current_app

logger = structlog.get_logger(__name__)


class ChunkingService:
    def chunk_text(self, text: str, chunk_size: int = None, overlap: int = None) -> List[dict]:
        """
        Split text into overlapping chunks. Returns list of {text, chunk_index, token_count}.
        """
        chunk_size = chunk_size or current_app.config.get("CHUNK_SIZE", 1000)
        overlap = overlap or current_app.config.get("CHUNK_OVERLAP", 200)

        # Split by paragraphs first, then by size
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
        chunks = []
        current_chunk = []
        current_len = 0

        for para in paragraphs:
            para_len = len(para)
            if current_len + para_len > chunk_size and current_chunk:
                chunk_text = "\n\n".join(current_chunk)
                chunks.append(chunk_text)
                # Keep overlap: last N chars worth of paragraphs
                overlap_text = ""
                for p in reversed(current_chunk):
                    if len(overlap_text) < overlap:
                        overlap_text = p + "\n\n" + overlap_text
                    else:
                        break
                current_chunk = [overlap_text.strip()] if overlap_text.strip() else []
                current_len = len(overlap_text)
            current_chunk.append(para)
            current_len += para_len

        if current_chunk:
            chunks.append("\n\n".join(current_chunk))

        result = []
        for i, chunk in enumerate(chunks):
            if chunk.strip():
                result.append({
                    "text": chunk.strip(),
                    "chunk_index": i,
                    "token_count": len(chunk.split()),
                })

        logger.info("chunking_complete", total_chunks=len(result))
        return result

    def chunk_pages(self, pages: List[dict], chunk_size: int = None, overlap: int = None) -> List[dict]:
        """Chunk with page-level metadata preserved."""
        chunks = []
        chunk_index = 0
        for page in pages:
            page_chunks = self.chunk_text(page["text"], chunk_size, overlap)
            for c in page_chunks:
                c["page_number"] = page["page_number"]
                c["chunk_index"] = chunk_index
                chunks.append(c)
                chunk_index += 1
        return chunks


chunking_service = ChunkingService()
