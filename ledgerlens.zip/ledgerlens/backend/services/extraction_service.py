"""
LedgerLens.ai — PDF Text Extraction Service
Extracts text from PDF documents using PyMuPDF with pdfminer fallback.
"""

import io
import structlog
from typing import List

logger = structlog.get_logger(__name__)


class ExtractionService:
    def extract_from_bytes(self, pdf_bytes: bytes) -> dict:
        """Extract text from PDF bytes. Returns dict with pages and full_text."""
        try:
            return self._extract_pymupdf(pdf_bytes)
        except Exception as e:
            logger.warning("pymupdf_failed_fallback", error=str(e))
            try:
                return self._extract_pdfminer(pdf_bytes)
            except Exception as e2:
                logger.error("extraction_complete_failure", error=str(e2))
                return {"pages": [], "full_text": "", "page_count": 0, "error": str(e2)}

    def _extract_pymupdf(self, pdf_bytes: bytes) -> dict:
        import fitz  # PyMuPDF
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        pages = []
        full_text = []
        for i, page in enumerate(doc):
            text = page.get_text("text")
            pages.append({"page_number": i + 1, "text": text, "char_count": len(text)})
            full_text.append(text)
        doc.close()
        return {"pages": pages, "full_text": "\n\n".join(full_text), "page_count": len(pages)}

    def _extract_pdfminer(self, pdf_bytes: bytes) -> dict:
        from pdfminer.high_level import extract_text_to_fp
        from pdfminer.layout import LAParams
        output = io.StringIO()
        extract_text_to_fp(io.BytesIO(pdf_bytes), output, laparams=LAParams())
        text = output.getvalue()
        return {"pages": [{"page_number": 1, "text": text, "char_count": len(text)}],
                "full_text": text, "page_count": 1}


extraction_service = ExtractionService()
