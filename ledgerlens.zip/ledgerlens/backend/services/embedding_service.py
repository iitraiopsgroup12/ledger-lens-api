"""
LedgerLens.ai — Embedding Service
Generates vector embeddings using Gemini Embedding model.
"""

import structlog
from typing import List
from flask import current_app

logger = structlog.get_logger(__name__)


class EmbeddingService:
    def __init__(self):
        self._configured = False

    def _configure(self):
        if not self._configured:
            import google.generativeai as genai
            genai.configure(api_key=current_app.config["GEMINI_API_KEY"])
            self._configured = True
            self._model = current_app.config.get("GEMINI_EMBEDDING_MODEL", "models/embedding-001")

    def embed_text(self, text: str) -> List[float]:
        try:
            self._configure()
            import google.generativeai as genai
            result = genai.embed_content(model=self._model, content=text, task_type="retrieval_document")
            return result["embedding"]
        except Exception as e:
            logger.error("embedding_error", error=str(e))
            return [0.0] * 768

    def embed_query(self, query: str) -> List[float]:
        try:
            self._configure()
            import google.generativeai as genai
            result = genai.embed_content(model=self._model, content=query, task_type="retrieval_query")
            return result["embedding"]
        except Exception as e:
            logger.error("embedding_query_error", error=str(e))
            return [0.0] * 768

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        return [self.embed_text(t) for t in texts]


embedding_service = EmbeddingService()
