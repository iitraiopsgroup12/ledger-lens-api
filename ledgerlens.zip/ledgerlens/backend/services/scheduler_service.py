"""
LedgerLens.ai — Scheduler Service
APScheduler jobs for periodic watchlist refresh via NSE MCP.
"""

import structlog
from datetime import datetime, timedelta
from flask import current_app

logger = structlog.get_logger(__name__)

FREQUENCY_DELTAS = {
    "daily": timedelta(days=1),
    "weekly": timedelta(weeks=1),
    "monthly": timedelta(days=30),
    "manual": None,
}


def run_watchlist_refresh(app):
    """
    Main scheduler job. Reads all watchlists, checks due companies,
    fetches MCP announcements, processes new documents.
    """
    with app.app_context():
        from models import Watchlist, Document, UpdateLog, Company
        from extensions import db
        from services.mcp_service import mcp_service

        logger.info("scheduler_job_start")
        start_time = datetime.utcnow()
        total_found = 0
        total_processed = 0

        now = datetime.utcnow()
        due_watchlists = Watchlist.query.filter(
            Watchlist.is_active == True,
            Watchlist.update_frequency != "manual",
            (Watchlist.next_check == None) | (Watchlist.next_check <= now),
        ).all()

        logger.info("scheduler_due_watchlists", count=len(due_watchlists))

        for wl in due_watchlists:
            try:
                company = wl.company
                if not company:
                    continue

                symbol = company.symbol
                existing_ids = [
                    d.nse_announcement_id for d in
                    Document.query.filter_by(company_id=company.id).all()
                    if d.nse_announcement_id
                ]

                new_announcements = mcp_service.identify_new_documents(symbol, existing_ids)
                total_found += len(new_announcements)

                for announcement in new_announcements:
                    _process_announcement(app, company, announcement)
                    total_processed += 1

                # Update next check time
                delta = FREQUENCY_DELTAS.get(wl.update_frequency)
                wl.last_checked = now
                wl.next_check = now + delta if delta else None

                company.last_updated = now

            except Exception as e:
                logger.error("scheduler_watchlist_error", company=wl.company_id, error=str(e))
                _log_update(db, None, "scheduler_run", "failed", str(e))

        db.session.commit()

        duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        _log_update(db, None, "scheduler_run", "success",
                    f"Checked {len(due_watchlists)} companies. Found {total_found}, processed {total_processed}.",
                    total_found, total_processed, duration_ms)
        db.session.commit()

        logger.info("scheduler_job_complete", found=total_found, processed=total_processed, duration_ms=duration_ms)
        return {"found": total_found, "processed": total_processed}


def _process_announcement(app, company, announcement: dict):
    """Download and ingest a new announcement document."""
    from models import Document
    from extensions import db
    from services.s3_service import s3_service

    doc_type = "annual_report" if announcement.get("is_annual_report") else "corporate_filing"
    name = announcement.get("subject", "Unknown Document")
    filing_date_str = announcement.get("date")
    filing_date = None
    if filing_date_str:
        try:
            filing_date = datetime.strptime(filing_date_str, "%Y-%m-%d")
        except Exception:
            pass

    doc = Document(
        company_id=company.id,
        name=name,
        document_type=doc_type,
        filing_date=filing_date,
        processing_status="pending",
        nse_announcement_id=announcement.get("announcement_id"),
        meta_data=announcement,
    )
    db.session.add(doc)
    db.session.flush()

    # If there's an attachment URL, attempt download
    attachment_url = announcement.get("attachment_url")
    if attachment_url:
        try:
            import httpx
            response = httpx.get(attachment_url, timeout=30, follow_redirects=True)
            if response.status_code == 200:
                pdf_bytes = response.content
                s3_key = s3_service.build_s3_key(company.symbol, doc_type, f"{doc.id}.pdf")
                upload_result = s3_service.upload_bytes(
                    pdf_bytes, s3_key,
                    metadata={"company": company.symbol, "document_id": doc.id}
                )
                if upload_result["success"]:
                    doc.s3_key = s3_key
                    doc.s3_bucket = upload_result["bucket"]
                    doc.file_size = len(pdf_bytes)
                    doc.processing_status = "downloaded"
        except Exception as e:
            logger.error("announcement_download_error", doc_id=doc.id, error=str(e))

    logger.info("announcement_ingested", doc_id=doc.id, symbol=company.symbol)


def _log_update(db, company_id, log_type, status, message, found=0, processed=0, duration_ms=None):
    from models import UpdateLog
    log = UpdateLog(
        company_id=company_id,
        log_type=log_type,
        status=status,
        message=message,
        documents_found=found,
        documents_processed=processed,
        duration_ms=duration_ms,
    )
    db.session.add(log)
