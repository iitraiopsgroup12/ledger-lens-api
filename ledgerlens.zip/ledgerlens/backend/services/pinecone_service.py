"""
LedgerLens.ai — Pinecone Vector Database Service
Handles all vector storage and similarity search operations for the RAG pipeline.
"""

import structlog
from typing import List, Optional
from flask import current_app

logger = structlog.get_logger(__name__)


class PineconeService:
    """Service for Pinecone vector database operations."""

    def __init__(self):
        self._index = None

    def _get_index(self):
        if self._index is None:
            from pinecone import Pinecone
            pc = Pinecone(api_key=current_app.config["PINECONE_API_KEY"])
            index_name = current_app.config["PINECONE_INDEX_NAME"]
            existing = [i.name for i in pc.list_indexes()]
            if index_name not in existing:
                pc.create_index(
                    name=index_name,
                    dimension=768,
                    metric="cosine",
                    spec={"serverless": {"cloud": "aws", "region": "us-east-1"}},
                )
            self._index = pc.Index(index_name)
        return self._index

    def upsert_vectors(self, vectors: List[dict]) -> dict:
        """Upsert a batch of vectors into Pinecone. Each vector: {id, values, metadata}"""
        try:
            index = self._get_index()
            batch_size = 100
            total_upserted = 0
            for i in range(0, len(vectors), batch_size):
                batch = vectors[i:i + batch_size]
                index.upsert(vectors=batch)
                total_upserted += len(batch)
            logger.info("pinecone_upsert_success", count=total_upserted)
            return {"success": True, "upserted": total_upserted}
        except Exception as e:
            logger.error("pinecone_upsert_error", error=str(e))
            return {"success": False, "error": str(e)}

    def query(self, embedding: List[float], top_k: int = 10, filter: dict = None) -> List[dict]:
        """Semantic similarity search in Pinecone."""
        try:
            index = self._get_index()
            params = {"vector": embedding, "top_k": top_k, "include_metadata": True}
            if filter:
                params["filter"] = filter
            result = index.query(**params)
            matches = []
            for match in result.get("matches", []):
                matches.append({
                    "id": match["id"],
                    "score": match["score"],
                    "metadata": match.get("metadata", {}),
                })
            return matches
        except Exception as e:
            logger.error("pinecone_query_error", error=str(e))
            return []

    def delete_by_document(self, document_id: str) -> bool:
        """Delete all vectors for a given document."""
        try:
            index = self._get_index()
            index.delete(filter={"document_id": document_id})
            logger.info("pinecone_delete_success", document_id=document_id)
            return True
        except Exception as e:
            logger.error("pinecone_delete_error", document_id=document_id, error=str(e))
            return False

    def delete_by_company(self, symbol: str) -> bool:
        """Delete all vectors for a given company symbol."""
        try:
            index = self._get_index()
            index.delete(filter={"symbol": symbol})
            return True
        except Exception as e:
            logger.error("pinecone_delete_company_error", symbol=symbol, error=str(e))
            return False

    def get_index_stats(self) -> dict:
        try:
            index = self._get_index()
            stats = index.describe_index_stats()
            return {"success": True, "stats": stats}
        except Exception as e:
            return {"success": False, "error": str(e)}


pinecone_service = PineconeService()
