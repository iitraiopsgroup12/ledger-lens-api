"""
LedgerLens.ai — AWS S3 Service
Handles all file storage operations: upload, download presigned URLs, and metadata.
"""

import boto3
import hashlib
import structlog
from botocore.exceptions import ClientError, NoCredentialsError
from flask import current_app
from typing import Optional, BinaryIO

logger = structlog.get_logger(__name__)


class S3Service:
    """Service for all AWS S3 operations."""

    def __init__(self):
        self._client = None
        self._bucket = None

    def _get_client(self):
        """Lazy-initialize S3 client."""
        if self._client is None:
            self._client = boto3.client(
                "s3",
                aws_access_key_id=current_app.config["AWS_ACCESS_KEY_ID"],
                aws_secret_access_key=current_app.config["AWS_SECRET_ACCESS_KEY"],
                region_name=current_app.config["AWS_REGION"],
            )
            self._bucket = current_app.config["S3_BUCKET_NAME"]
        return self._client

    def upload_file(
        self,
        file_data: BinaryIO,
        s3_key: str,
        content_type: str = "application/pdf",
        metadata: dict = None,
    ) -> dict:
        """
        Upload a file to S3.
        Returns dict with success status and s3_key.
        """
        try:
            client = self._get_client()
            extra_args = {
                "ContentType": content_type,
                "ServerSideEncryption": "AES256",
            }
            if metadata:
                extra_args["Metadata"] = {k: str(v) for k, v in metadata.items()}

            client.upload_fileobj(file_data, self._bucket, s3_key, ExtraArgs=extra_args)

            logger.info("s3_upload_success", s3_key=s3_key, bucket=self._bucket)
            return {
                "success": True,
                "s3_key": s3_key,
                "bucket": self._bucket,
            }

        except NoCredentialsError:
            logger.error("s3_no_credentials")
            return {"success": False, "error": "AWS credentials not configured"}

        except ClientError as e:
            logger.error("s3_upload_error", s3_key=s3_key, error=str(e))
            return {"success": False, "error": str(e)}

    def upload_bytes(
        self,
        data: bytes,
        s3_key: str,
        content_type: str = "application/pdf",
        metadata: dict = None,
    ) -> dict:
        """Upload raw bytes to S3."""
        import io
        return self.upload_file(io.BytesIO(data), s3_key, content_type, metadata)

    def get_presigned_url(self, s3_key: str, expiry: int = None) -> Optional[str]:
        """
        Generate a presigned download URL for an S3 object.
        """
        try:
            client = self._get_client()
            expiry = expiry or current_app.config.get("S3_PRESIGNED_URL_EXPIRY", 3600)

            url = client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self._bucket, "Key": s3_key},
                ExpiresIn=expiry,
            )

            logger.info("s3_presigned_url_generated", s3_key=s3_key)
            return url

        except ClientError as e:
            logger.error("s3_presigned_url_error", s3_key=s3_key, error=str(e))
            return None

    def download_file(self, s3_key: str) -> Optional[bytes]:
        """Download file from S3 as bytes."""
        try:
            client = self._get_client()
            response = client.get_object(Bucket=self._bucket, Key=s3_key)
            data = response["Body"].read()
            logger.info("s3_download_success", s3_key=s3_key, size=len(data))
            return data

        except ClientError as e:
            logger.error("s3_download_error", s3_key=s3_key, error=str(e))
            return None

    def delete_file(self, s3_key: str) -> bool:
        """Delete a file from S3."""
        try:
            client = self._get_client()
            client.delete_object(Bucket=self._bucket, Key=s3_key)
            logger.info("s3_delete_success", s3_key=s3_key)
            return True
        except ClientError as e:
            logger.error("s3_delete_error", s3_key=s3_key, error=str(e))
            return False

    def file_exists(self, s3_key: str) -> bool:
        """Check if an S3 object exists."""
        try:
            client = self._get_client()
            client.head_object(Bucket=self._bucket, Key=s3_key)
            return True
        except ClientError:
            return False

    @staticmethod
    def build_s3_key(symbol: str, document_type: str, filename: str) -> str:
        """Build a structured S3 key for a document."""
        safe_symbol = symbol.upper().replace("/", "-")
        safe_type = document_type.lower().replace(" ", "_")
        safe_filename = filename.replace(" ", "_")
        return f"documents/{safe_symbol}/{safe_type}/{safe_filename}"

    @staticmethod
    def build_analyst_report_key(symbol: str, broker: str, filename: str) -> str:
        """Build S3 key for analyst reports."""
        safe_symbol = symbol.upper().replace("/", "-")
        safe_broker = broker.lower().replace(" ", "_")
        safe_filename = filename.replace(" ", "_")
        return f"analyst_reports/{safe_symbol}/{safe_broker}/{safe_filename}"

    @staticmethod
    def compute_file_hash(data: bytes) -> str:
        """Compute SHA-256 hash of file content for deduplication."""
        return hashlib.sha256(data).hexdigest()


# Module-level singleton
s3_service = S3Service()
