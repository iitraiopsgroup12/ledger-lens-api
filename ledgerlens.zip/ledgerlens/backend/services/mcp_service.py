"""
LedgerLens.ai — NSE MCP Service
Wraps the NSE MCP Server for fetching corporate announcements and annual reports.
The ONLY automated document source in the platform.
"""

import asyncio
import structlog
from typing import Optional
from flask import current_app

logger = structlog.get_logger(__name__)


class MCPService:
    """
    Service wrapper for the NSE MCP Server.
    Uses streamable HTTP client to communicate with the local MCP server at port 3000.
    """

    def __init__(self, mcp_url: str = None):
        self.mcp_url = mcp_url or "http://localhost:3000/mcp"

    async def get_corporate_announcements(self, symbol: str) -> dict:
        """
        Fetch corporate announcements for a given NSE symbol via MCP.
        Returns raw tool result from nse_corporate_announcements tool.
        """
        try:
            from mcp.client.streamable_http import streamablehttp_client
            from mcp import ClientSession

            logger.info("mcp_fetch_start", symbol=symbol, url=self.mcp_url)

            async with streamablehttp_client(self.mcp_url) as (read, write, _):
                async with ClientSession(read, write) as session:
                    await session.initialize()

                    result = await session.call_tool(
                        "nse_corporate_announcements",
                        {"symbol": symbol}
                    )

                    logger.info("mcp_fetch_success", symbol=symbol)
                    return {
                        "success": True,
                        "symbol": symbol,
                        "data": self._parse_result(result),
                    }

        except ImportError:
            logger.error("mcp_import_error", symbol=symbol)
            return self._mock_response(symbol)

        except Exception as e:
            logger.error("mcp_fetch_error", symbol=symbol, error=str(e))
            return {
                "success": False,
                "symbol": symbol,
                "error": str(e),
                "data": [],
            }

    def _parse_result(self, result) -> list:
        """Parse MCP tool result into structured announcement list."""
        announcements = []

        if not result or not result.content:
            return announcements

        for content_item in result.content:
            if hasattr(content_item, "text"):
                # Parse text content — expected to be JSON or structured text
                import json
                try:
                    parsed = json.loads(content_item.text)
                    if isinstance(parsed, list):
                        announcements.extend(parsed)
                    elif isinstance(parsed, dict):
                        announcements.append(parsed)
                except json.JSONDecodeError:
                    # Raw text announcement
                    announcements.append({"raw": content_item.text})

        return announcements

    def _mock_response(self, symbol: str) -> dict:
        """
        Mock MCP response for development/testing when MCP server is unavailable.
        Returns realistic NSE announcement structure.
        """
        logger.warning("mcp_using_mock_response", symbol=symbol)
        return {
            "success": True,
            "symbol": symbol,
            "data": [
                {
                    "announcement_id": f"NSE_{symbol}_AR_2024",
                    "symbol": symbol,
                    "company_name": f"{symbol} Limited",
                    "announcement_type": "Annual Report",
                    "subject": f"Annual Report for FY 2023-24",
                    "description": f"Annual Report for the financial year 2023-24 submitted to NSE",
                    "date": "2024-09-15",
                    "attachment_url": None,
                    "is_annual_report": True,
                    "financial_year": "2023-24",
                },
                {
                    "announcement_id": f"NSE_{symbol}_CF_2024_Q3",
                    "symbol": symbol,
                    "company_name": f"{symbol} Limited",
                    "announcement_type": "Financial Results",
                    "subject": "Unaudited Standalone & Consolidated Financial Results Q3 FY24",
                    "description": "Board Meeting outcome: Financial Results for Q3 FY24",
                    "date": "2024-01-10",
                    "attachment_url": None,
                    "is_annual_report": False,
                    "financial_year": "2023-24",
                },
            ],
            "mock": True,
        }

    def fetch_announcements_sync(self, symbol: str) -> dict:
        """Synchronous wrapper around the async fetch method."""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If there's already a running loop (e.g., in Flask context)
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    future = pool.submit(asyncio.run, self.get_corporate_announcements(symbol))
                    return future.result(timeout=30)
            else:
                return loop.run_until_complete(self.get_corporate_announcements(symbol))
        except Exception as e:
            logger.error("mcp_sync_fetch_error", symbol=symbol, error=str(e))
            return self._mock_response(symbol)

    def identify_new_documents(self, symbol: str, existing_ids: list) -> list:
        """
        Fetch announcements and return only new ones not already in the database.
        """
        result = self.fetch_announcements_sync(symbol)
        if not result.get("success"):
            return []

        new_docs = []
        for announcement in result.get("data", []):
            ann_id = announcement.get("announcement_id")
            if ann_id and ann_id not in existing_ids:
                new_docs.append(announcement)

        return new_docs


# Module-level singleton
mcp_service = MCPService()
