"""
LedgerLens.ai — Gemini LLM Service
Wraps Google Gemini for chat completions and analysis.
"""

import structlog
from flask import current_app

logger = structlog.get_logger(__name__)


class GeminiService:
    def __init__(self):
        self._model = None

    def _get_model(self):
        if self._model is None:
            import google.generativeai as genai
            genai.configure(api_key=current_app.config["GEMINI_API_KEY"])
            self._model = genai.GenerativeModel(current_app.config["GEMINI_MODEL"])
        return self._model

    def generate(self, prompt: str, system_prompt: str = None) -> str:
        try:
            model = self._get_model()
            full_prompt = f"{system_prompt}\n\n{prompt}" if system_prompt else prompt
            response = model.generate_content(full_prompt)
            return response.text
        except Exception as e:
            logger.error("gemini_generate_error", error=str(e))
            return f"Error generating response: {str(e)}"

    def generate_with_context(self, query: str, context_chunks: list, system_prompt: str = None) -> str:
        context = "\n\n---\n\n".join([c.get("text", "") for c in context_chunks])
        prompt = f"""Use the following context from financial documents to answer the question.

CONTEXT:
{context}

QUESTION:
{query}

Provide a detailed, structured answer based on the context. If the context does not contain enough information, say so clearly."""
        return self.generate(prompt, system_prompt)

    def analyze_sentiment(self, text: str) -> dict:
        prompt = f"""Analyze the sentiment of this analyst report excerpt. Return JSON with:
- rating: one of "buy", "hold", "sell", "neutral"
- sentiment_score: float from -1.0 (very bearish) to 1.0 (very bullish)
- key_points: list of 3 key observations
- summary: one sentence summary

TEXT:
{text[:3000]}

Return only valid JSON."""
        try:
            result = self.generate(prompt)
            import json, re
            clean = re.sub(r"```json|```", "", result).strip()
            return json.loads(clean)
        except Exception as e:
            logger.error("gemini_sentiment_error", error=str(e))
            return {"rating": "neutral", "sentiment_score": 0.0, "key_points": [], "summary": "Analysis unavailable"}


gemini_service = GeminiService()
