"""LedgerLens.ai — Analyst Reports Blueprint (manual upload only)"""

import os
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from extensions import db
from models import AnalystReport, Company
from services.s3_service import s3_service
from datetime import datetime
import structlog

analyst_reports_bp = Blueprint("analyst_reports", __name__)
logger = structlog.get_logger(__name__)


@analyst_reports_bp.route("", methods=["GET"])
@jwt_required()
def list_analyst_reports():
    """GET /api/v1/analyst-reports"""
    symbol = request.args.get("symbol")
    page = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 20))

    query = AnalystReport.query
    if symbol:
        company = Company.query.filter_by(symbol=symbol.upper()).first()
        if company:
            query = query.filter_by(company_id=company.id)

    paginated = query.order_by(AnalystReport.report_date.desc()).paginate(page=page, per_page=per_page)

    return jsonify({
        "analyst_reports": [r.to_dict() for r in paginated.items],
        "total": paginated.total,
        "page": page,
        "pages": paginated.pages,
    }), 200


@analyst_reports_bp.route("", methods=["POST"])
@jwt_required()
def upload_analyst_report():
    """
    POST /api/v1/analyst-reports — manual PDF upload
    Form fields: symbol, broker_name, report_date, rating, target_price, current_price
    File field: file (PDF)
    """
    user_id = get_jwt_identity()

    symbol = request.form.get("symbol", "").upper().strip()
    broker_name = request.form.get("broker_name", "").strip()
    report_date_str = request.form.get("report_date")
    rating = request.form.get("rating", "").lower().strip()
    target_price = request.form.get("target_price")
    current_price = request.form.get("current_price")

    if not symbol or not broker_name or not report_date_str:
        return jsonify({"error": "symbol, broker_name, and report_date are required"}), 400

    if rating and rating not in ("buy", "hold", "sell", "neutral"):
        return jsonify({"error": "rating must be buy, hold, sell, or neutral"}), 400

    try:
        report_date = datetime.strptime(report_date_str, "%Y-%m-%d")
    except ValueError:
        return jsonify({"error": "report_date must be in YYYY-MM-DD format"}), 400

    # Find or create company
    company = Company.query.filter_by(symbol=symbol).first()
    if not company:
        company = Company(symbol=symbol, name=symbol)
        db.session.add(company)
        db.session.flush()

    # Handle file upload
    file = request.files.get("file")
    s3_key = None
    s3_bucket = None
    file_size = None

    if file and file.filename:
        filename = f"{symbol}_{broker_name}_{report_date_str}_{file.filename}"
        s3_key = s3_service.build_analyst_report_key(symbol, broker_name, filename)
        pdf_bytes = file.read()
        file_size = len(pdf_bytes)
        result = s3_service.upload_bytes(
            pdf_bytes, s3_key, "application/pdf",
            metadata={"symbol": symbol, "broker": broker_name}
        )
        if not result.get("success"):
            return jsonify({"error": "Failed to upload file to S3", "details": result.get("error")}), 500
        s3_bucket = result["bucket"]

    report = AnalystReport(
        company_id=company.id,
        broker_name=broker_name,
        report_date=report_date,
        rating=rating or None,
        target_price=float(target_price) if target_price else None,
        current_price=float(current_price) if current_price else None,
        s3_key=s3_key,
        s3_bucket=s3_bucket,
        file_size=file_size,
        uploaded_by=user_id,
    )
    db.session.add(report)
    db.session.commit()

    logger.info("analyst_report_uploaded", report_id=report.id, symbol=symbol)
    return jsonify({"analyst_report": report.to_dict()}), 201


@analyst_reports_bp.route("/<report_id>/download", methods=["GET"])
@jwt_required()
def download_analyst_report(report_id):
    report = AnalystReport.query.get(report_id)
    if not report:
        return jsonify({"error": "Report not found"}), 404
    if not report.s3_key:
        return jsonify({"error": "No file available"}), 404
    url = s3_service.get_presigned_url(report.s3_key)
    if not url:
        return jsonify({"error": "Could not generate download URL"}), 500
    return jsonify({"download_url": url, "expires_in": 3600}), 200
