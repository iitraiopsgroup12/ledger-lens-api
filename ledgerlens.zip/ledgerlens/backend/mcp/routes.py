"""LedgerLens.ai — MCP Blueprint"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from services.mcp_service import mcp_service
import structlog

mcp_bp = Blueprint("mcp", __name__)
logger = structlog.get_logger(__name__)


@mcp_bp.route("/<symbol>/announcements", methods=["GET"])
@jwt_required()
def get_announcements(symbol):
    """GET /api/v1/mcp/<symbol>/announcements — fetch via NSE MCP"""
    result = mcp_service.fetch_announcements_sync(symbol.upper())
    return jsonify(result), 200 if result.get("success") else 500


@mcp_bp.route("/<symbol>/refresh", methods=["POST"])
@jwt_required()
def refresh_company(symbol):
    """POST /api/v1/mcp/<symbol>/refresh — manual refresh for a company"""
    from models import Company, Document
    from extensions import db
    from services.scheduler_service import _process_announcement

    from flask import current_app as app

    company = Company.query.filter_by(symbol=symbol.upper()).first()
    if not company:
        return jsonify({"error": "Company not found in database"}), 404

    existing_ids = [
        d.nse_announcement_id for d in
        Document.query.filter_by(company_id=company.id).all()
        if d.nse_announcement_id
    ]

    new_announcements = mcp_service.identify_new_documents(symbol.upper(), existing_ids)

    processed = 0
    for ann in new_announcements:
        try:
            _process_announcement(app._get_current_object(), company, ann)
            processed += 1
        except Exception as e:
            logger.error("mcp_refresh_error", symbol=symbol, error=str(e))

    db.session.commit()

    return jsonify({
        "symbol": symbol,
        "new_announcements_found": len(new_announcements),
        "documents_ingested": processed,
    }), 200
