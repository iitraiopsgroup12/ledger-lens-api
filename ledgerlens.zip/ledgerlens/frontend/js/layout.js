/**
 * LedgerLens.ai — Sidebar & Layout Template
 * Call renderLayout(pageTitle, activeNav) to inject layout into #app
 */

function renderLayout(pageTitle, activeNav, contentHtml) {
  const app = document.getElementById("app");
  app.innerHTML = `
    <div class="app-layout">
      <!-- Sidebar -->
      <nav class="sidebar">
        <div class="sidebar-brand">
          <a href="/dashboard.html" class="sidebar-logo">
            <div class="sidebar-logo-icon">📊</div>
            <div>
              <span>LedgerLens</span>
              <span class="sidebar-logo-sub">.ai</span>
            </div>
          </a>
        </div>

        <div class="sidebar-nav">
          <div class="sidebar-section-label">Platform</div>
          <a href="/dashboard.html" class="sidebar-link ${activeNav === 'dashboard' ? 'active' : ''}">
            <span class="icon">🏠</span> Dashboard
          </a>
          <a href="/watchlist.html" class="sidebar-link ${activeNav === 'watchlist' ? 'active' : ''}">
            <span class="icon">⭐</span> Watchlist
          </a>
          <a href="/companies.html" class="sidebar-link ${activeNav === 'companies' ? 'active' : ''}">
            <span class="icon">🏢</span> Companies
          </a>

          <div class="sidebar-section-label">Research</div>
          <a href="/documents.html" class="sidebar-link ${activeNav === 'documents' ? 'active' : ''}">
            <span class="icon">📄</span> Documents
          </a>
          <a href="/compare.html" class="sidebar-link ${activeNav === 'compare' ? 'active' : ''}">
            <span class="icon">⚖️</span> Compare
          </a>
          <a href="/chat.html" class="sidebar-link ${activeNav === 'chat' ? 'active' : ''}">
            <span class="icon">💬</span> Chat
          </a>
          <a href="/analyst_reports.html" class="sidebar-link ${activeNav === 'analyst_reports' ? 'active' : ''}">
            <span class="icon">📋</span> Analyst Reports
          </a>
        </div>

        <div class="sidebar-footer">
          <div class="sidebar-user">
            <div class="sidebar-avatar" id="sidebar-avatar">A</div>
            <div style="flex:1;overflow:hidden;">
              <div class="sidebar-user-name" id="sidebar-user-name">Loading...</div>
              <div class="sidebar-user-role">Equity Analyst</div>
            </div>
            <button id="logout-btn" title="Logout" style="background:none;border:none;cursor:pointer;color:var(--text-sidebar);font-size:16px;padding:4px;">⏏</button>
          </div>
        </div>
      </nav>

      <!-- Main -->
      <div class="main-content">
        <div class="topbar">
          <span class="topbar-title">${pageTitle}</span>
          <div class="topbar-actions" id="topbar-actions"></div>
        </div>
        <div class="page-content" id="page-content">
          ${contentHtml || ''}
        </div>
      </div>
    </div>
  `;

  initSidebar();
}
