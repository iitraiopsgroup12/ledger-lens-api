/**
 * LedgerLens.ai — Core JS
 * API client, auth helpers, toast, and shared utilities.
 */

const API_BASE = "/api/v1";

// ─── Auth ─────────────────────────────────────────────────

const Auth = {
  getToken: () => localStorage.getItem("ll_token"),
  getUser: () => {
    try { return JSON.parse(localStorage.getItem("ll_user")); } catch { return null; }
  },
  setSession: (token, user) => {
    localStorage.setItem("ll_token", token);
    localStorage.setItem("ll_user", JSON.stringify(user));
  },
  clearSession: () => {
    localStorage.removeItem("ll_token");
    localStorage.removeItem("ll_user");
  },
  isLoggedIn: () => !!localStorage.getItem("ll_token"),
  requireAuth: () => {
    if (!Auth.isLoggedIn()) {
      window.location.href = "/login.html";
      return false;
    }
    return true;
  },
  logout: () => {
    Auth.clearSession();
    window.location.href = "/login.html";
  },
};

// ─── API Client ───────────────────────────────────────────

const api = {
  async request(method, path, body = null, isFormData = false) {
    const headers = {};
    if (!isFormData) headers["Content-Type"] = "application/json";
    const token = Auth.getToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;

    const opts = { method, headers };
    if (body) opts.body = isFormData ? body : JSON.stringify(body);

    try {
      const res = await fetch(`${API_BASE}${path}`, opts);
      if (res.status === 401) { Auth.logout(); return null; }
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || data.message || "Request failed");
      return data;
    } catch (e) {
      throw e;
    }
  },

  get: (path) => api.request("GET", path),
  post: (path, body) => api.request("POST", path, body),
  patch: (path, body) => api.request("PATCH", path, body),
  delete: (path) => api.request("DELETE", path),
  postForm: (path, formData) => api.request("POST", path, formData, true),
};

// ─── Toast ────────────────────────────────────────────────

const Toast = {
  _container: null,
  _getContainer() {
    if (!this._container) {
      this._container = document.createElement("div");
      this._container.className = "toast-container";
      document.body.appendChild(this._container);
    }
    return this._container;
  },
  show(message, type = "info") {
    const container = this._getContainer();
    const el = document.createElement("div");
    el.className = `toast toast-${type}`;
    const icons = { success: "✓", error: "✗", info: "ℹ" };
    el.innerHTML = `<span>${icons[type] || "ℹ"}</span> <span>${message}</span>`;
    container.appendChild(el);
    setTimeout(() => { el.style.opacity = "0"; el.style.transition = "opacity 0.3s"; setTimeout(() => el.remove(), 300); }, 3500);
  },
  success: (msg) => Toast.show(msg, "success"),
  error: (msg) => Toast.show(msg, "error"),
  info: (msg) => Toast.show(msg, "info"),
};

// ─── Sidebar Active State ─────────────────────────────────

function initSidebar() {
  const user = Auth.getUser();
  if (user) {
    const nameEl = document.getElementById("sidebar-user-name");
    const initEl = document.getElementById("sidebar-avatar");
    if (nameEl) nameEl.textContent = user.full_name || user.email;
    if (initEl) initEl.textContent = (user.full_name || user.email || "A")[0].toUpperCase();
  }

  // Highlight active link
  const path = window.location.pathname.split("/").pop();
  document.querySelectorAll(".sidebar-link").forEach(link => {
    const href = link.getAttribute("href");
    if (href && href.includes(path)) link.classList.add("active");
  });

  // Logout
  const logoutBtn = document.getElementById("logout-btn");
  if (logoutBtn) logoutBtn.addEventListener("click", Auth.logout);
}

// ─── Format Helpers ───────────────────────────────────────

const fmt = {
  date: (iso) => {
    if (!iso) return "—";
    return new Date(iso).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  },
  number: (n) => n == null ? "—" : Number(n).toLocaleString("en-IN"),
  currency: (n) => n == null ? "—" : `₹${Number(n).toLocaleString("en-IN")}`,
  status: (s) => {
    const map = {
      completed: ["success", "Completed"],
      processing: ["info", "Processing"],
      pending: ["warning", "Pending"],
      failed: ["danger", "Failed"],
      downloaded: ["info", "Downloaded"],
    };
    const [type, label] = map[s] || ["neutral", s || "Unknown"];
    return `<span class="badge badge-${type}">${label}</span>`;
  },
  rating: (r) => {
    if (!r) return `<span class="badge badge-neutral">N/A</span>`;
    return `<span class="badge badge-${r}">${r.toUpperCase()}</span>`;
  },
  docType: (t) => {
    const map = { annual_report: "Annual Report", corporate_filing: "Corporate Filing" };
    return map[t] || t;
  },
};

// ─── Modal Helper ─────────────────────────────────────────

function openModal(id) {
  const m = document.getElementById(id);
  if (m) { m.style.display = "flex"; document.body.style.overflow = "hidden"; }
}

function closeModal(id) {
  const m = document.getElementById(id);
  if (m) { m.style.display = "none"; document.body.style.overflow = ""; }
}

// ─── Tabs ─────────────────────────────────────────────────

function initTabs(containerSelector) {
  document.querySelectorAll(containerSelector + " .tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const tabId = btn.dataset.tab;
      const parent = btn.closest(".tabs-wrapper") || document;
      parent.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      parent.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      const panel = parent.querySelector(`#${tabId}`);
      if (panel) panel.classList.add("active");
    });
  });
}

// ─── Loading State ────────────────────────────────────────

function setLoading(el, loading, text = "Loading...") {
  if (loading) {
    el.innerHTML = `<div class="loading-overlay"><div class="spinner"></div><span>${text}</span></div>`;
  }
}

// ─── Pagination ───────────────────────────────────────────

function renderPagination(container, page, pages, onPageChange) {
  if (pages <= 1) { container.innerHTML = ""; return; }
  let html = `<div class="d-flex gap-2 align-center" style="margin-top:16px">`;
  html += `<button class="btn btn-ghost btn-sm" ${page <= 1 ? "disabled" : ""} onclick="(${onPageChange})(${page - 1})">‹ Prev</button>`;
  html += `<span class="text-muted fs-13">Page ${page} of ${pages}</span>`;
  html += `<button class="btn btn-ghost btn-sm" ${page >= pages ? "disabled" : ""} onclick="(${onPageChange})(${page + 1})">Next ›</button>`;
  html += `</div>`;
  container.innerHTML = html;
}

// Auto-init on DOM ready
document.addEventListener("DOMContentLoaded", () => {
  if (document.querySelector(".sidebar")) initSidebar();
  initTabs(".tabs-wrapper");
});
